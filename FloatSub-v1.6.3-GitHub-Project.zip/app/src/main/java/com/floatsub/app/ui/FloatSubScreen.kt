package com.floatsub.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.floatsub.app.data.AiTranslationMode
import com.floatsub.app.data.DeepgramLanguage
import com.floatsub.app.data.FloatSubSettings
import com.floatsub.app.data.SubtitleBgStyle
import com.floatsub.app.data.SubtitleFontSize
import com.floatsub.app.data.SubtitleTextColor
import com.floatsub.app.translation.ApiKeyCheckResult

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun FloatSubScreen(
    settings: FloatSubSettings,
    isServiceRunning: Boolean,
    hasOverlayPermission: Boolean,
    isTestingKeys: Boolean,
    keyCheckResults: List<ApiKeyCheckResult>,
    onSaveApiKeys: (deepgram: String, groq: String, gemini: String) -> Unit,
    onTestApiKeys: (deepgram: String, groq: String, gemini: String) -> Unit,
    onSelectLanguage: (DeepgramLanguage) -> Unit,
    onToggleOpus: (Boolean) -> Unit,
    onSelectAiMode: (AiTranslationMode) -> Unit,
    onUpdateAppearance: (SubtitleFontSize, SubtitleTextColor, SubtitleBgStyle) -> Unit,
    onResetOverlayPosition: () -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onStartCaptureClick: () -> Unit,
    onStopCaptureClick: () -> Unit
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    var deepgramInput by rememberSaveable(settings.deepgramApiKey) {
        mutableStateOf(settings.deepgramApiKey)
    }
    var groqInput by rememberSaveable(settings.groqApiKey) {
        mutableStateOf(settings.groqApiKey)
    }
    var geminiInput by rememberSaveable(settings.geminiApiKey) {
        mutableStateOf(settings.geminiApiKey)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "FloatSub",
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "v1.6.3",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                ControlHeaderCard(
                    isRunning = isServiceRunning,
                    hasOverlayPermission = hasOverlayPermission,
                    onRequestOverlayPermission = onRequestOverlayPermission,
                    onStartClick = {
                        onSaveApiKeys(deepgramInput, groqInput, geminiInput)
                        onStartCaptureClick()
                    },
                    onStopClick = onStopCaptureClick
                )

                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("المحركات والمفاتيح") }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("مظهر الترجمة") }
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (selectedTab == 0) {
                        EnginesAndKeysTab(
                            settings = settings,
                            deepgramInput = deepgramInput,
                            groqInput = groqInput,
                            geminiInput = geminiInput,
                            isTestingKeys = isTestingKeys,
                            keyCheckResults = keyCheckResults,
                            onDeepgramChange = {
                                deepgramInput = it
                                onSaveApiKeys(it, groqInput, geminiInput)
                            },
                            onGroqChange = {
                                groqInput = it
                                onSaveApiKeys(deepgramInput, it, geminiInput)
                            },
                            onGeminiChange = {
                                geminiInput = it
                                onSaveApiKeys(deepgramInput, groqInput, it)
                            },
                            onTestKeys = {
                                onTestApiKeys(deepgramInput, groqInput, geminiInput)
                            },
                            onSelectLanguage = onSelectLanguage,
                            onToggleOpus = onToggleOpus,
                            onSelectAiMode = onSelectAiMode
                        )
                    } else {
                        AppearanceTab(
                            settings = settings,
                            onUpdateAppearance = onUpdateAppearance,
                            onResetOverlayPosition = onResetOverlayPosition
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ControlHeaderCard(
    isRunning: Boolean,
    hasOverlayPermission: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onStartClick: () -> Unit,
    onStopClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                color = if (isRunning) Color(0xFF22C55E) else Color(0xFF9CA3AF),
                                shape = CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isRunning) "الترجمة العائمة تعمل الآن" else "الخدمة متوقفة",
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (!hasOverlayPermission) {
                OutlinedButton(
                    onClick = onRequestOverlayPermission,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("منح إذن الظهور فوق التطبيقات أولاً")
                }
            } else if (!isRunning) {
                Button(
                    onClick = onStartClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF16A34A)
                    )
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("بدء الترجمة الفورية وتصغير التطبيق")
                }
            } else {
                Button(
                    onClick = onStopClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDC2626)
                    )
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إيقاف الترجمة وإغلاق النافذة العائمة")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EnginesAndKeysTab(
    settings: FloatSubSettings,
    deepgramInput: String,
    groqInput: String,
    geminiInput: String,
    isTestingKeys: Boolean,
    keyCheckResults: List<ApiKeyCheckResult>,
    onDeepgramChange: (String) -> Unit,
    onGroqChange: (String) -> Unit,
    onGeminiChange: (String) -> Unit,
    onTestKeys: () -> Unit,
    onSelectLanguage: (DeepgramLanguage) -> Unit,
    onToggleOpus: (Boolean) -> Unit,
    onSelectAiMode: (AiTranslationMode) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "مفاتيح الذكاء الاصطناعي والصوت (اختيارية)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "إذا تُركت مفاتيح الصوت فارغة سيعمل محرك Vosk الأوفلاين تلقائياً.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SecretApiKeyField(
                label = "مفتاح Deepgram API (البث الفوري الأساسي)",
                value = deepgramInput,
                onValueChange = onDeepgramChange
            )

            SecretApiKeyField(
                label = "مفتاح Groq API (Whisper + Llama 3.1 Instant)",
                value = groqInput,
                onValueChange = onGroqChange
            )

            SecretApiKeyField(
                label = "مفتاح Gemini API (Gemini 2.0 Flash)",
                value = geminiInput,
                onValueChange = onGeminiChange
            )

            OutlinedButton(
                onClick = onTestKeys,
                enabled = !isTestingKeys,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isTestingKeys) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("جارٍ فحص المفاتيح وتصفير التهدئة...")
                } else {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("اختبار المفاتيح وتصفير فترات التهدئة")
                }
            }

            if (keyCheckResults.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    keyCheckResults.forEach { res ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (res.isValid) Icons.Default.CheckCircle else Icons.Default.Error,
                                contentDescription = null,
                                tint = if (res.isValid) Color(0xFF22C55E) else Color(0xFFEF4444),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${res.provider}: ${res.message}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "لغة الصوت وضغط البث (Deepgram / Whisper)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                DeepgramLanguage.entries.forEach { lang ->
                    FilterChip(
                        selected = settings.sourceLanguage == lang,
                        onClick = { onSelectLanguage(lang) },
                        label = { Text(lang.labelAr) }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("ضغط الصوت الذكي (Opus 24kbps)", fontWeight = FontWeight.Medium)
                    Text(
                        text = "يوفر استهلاك الإنترنت مع تحول ذاتي تلقائي إلى PCM خلال 8 ثوانٍ عند الحاجة",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = settings.enableOpusCompression,
                    onCheckedChange = onToggleOpus
                )
            }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "وضع محرك الترجمة إلى العربية السينمائية",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            AiTranslationMode.entries.forEach { mode ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = settings.aiMode == mode,
                        onClick = { onSelectAiMode(mode) }
                    )
                    Text(
                        text = mode.labelAr,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AppearanceTab(
    settings: FloatSubSettings,
    onUpdateAppearance: (SubtitleFontSize, SubtitleTextColor, SubtitleBgStyle) -> Unit,
    onResetOverlayPosition: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "معاينة شكل الترجمة السينمائية",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .background(Color(0xFF1E293B), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                val previewBg = if (settings.bgStyle == SubtitleBgStyle.NONE) {
                    Color.Transparent
                } else {
                    Color(settings.bgStyle.colorArgb)
                }

                Text(
                    text = "هذه معاينة للترجمة العربية السينمائية\nفوق مشغل الفيديو دون حجب اللمس",
                    fontSize = settings.fontSize.sp.sp,
                    color = Color(settings.textColor.colorArgb),
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .background(previewBg, RoundedCornerShape(10.dp))
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("حجم الخط", fontWeight = FontWeight.Bold)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SubtitleFontSize.entries.forEach { size ->
                    FilterChip(
                        selected = settings.fontSize == size,
                        onClick = {
                            onUpdateAppearance(size, settings.textColor, settings.bgStyle)
                        },
                        label = { Text(size.labelAr) }
                    )
                }
            }

            Text("لون النص", fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SubtitleTextColor.entries.forEach { colorOpt ->
                    FilterChip(
                        selected = settings.textColor == colorOpt,
                        onClick = {
                            onUpdateAppearance(settings.fontSize, colorOpt, settings.bgStyle)
                        },
                        label = { Text(colorOpt.labelAr) }
                    )
                }
            }

            Text("خلفية النص", fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SubtitleBgStyle.entries.forEach { bgOpt ->
                    FilterChip(
                        selected = settings.bgStyle == bgOpt,
                        onClick = {
                            onUpdateAppearance(settings.fontSize, settings.textColor, bgOpt)
                        },
                        label = { Text(bgOpt.labelAr) }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الارتفاع الرأسي الحالي: ${settings.overlayYOffsetPx}px",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedButton(onClick = onResetOverlayPosition) {
                    Text("إعادة الضبط (180px)")
                }
            }
        }
    }
}

@Composable
private fun SecretApiKeyField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    var visible by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = {
            IconButton(onClick = { visible = !visible }) {
                Icon(
                    imageVector = if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = null
                )
            }
        },
        modifier = Modifier.fillMaxWidth()
    )
}
