package com.floatsub.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class DeepgramLanguage(val code: String, val labelAr: String) {
    EN("en", "الإنجليزية (en)"),
    DE("de", "الألمانية (de)"),
    IT("it", "الإيطالية (it)"),
    FR("fr", "الفرنسية (fr)"),
    ES("es", "الإسبانية (es)"),
    ES_419("es-419", "الإسبانية المكسيكية (es-419)"),
    JA("ja", "اليابانية (ja)"),
    MULTI("multi", "تلقائي متعدد (multi)");

    companion object {
        fun fromCode(code: String?): DeepgramLanguage =
            entries.firstOrNull { it.code == code } ?: EN
    }
}

enum class AiTranslationMode(val labelAr: String) {
    AUTO_HYBRID("هجين تلقائي (Groq + Gemini)"),
    GROQ_ONLY("Groq AI فقط"),
    GEMINI_ONLY("Gemini AI فقط"),
    INSTANT_GOOGLE("ترجمة جوجل السريعة فقط"),
    OFFLINE_ONLY("أوفلاين فقط (ML Kit)")
}

enum class SubtitleFontSize(val sp: Int, val labelAr: String) {
    SMALL(16, "صغير (16sp)"),
    MEDIUM(20, "متوسط (20sp)"),
    LARGE(24, "كبير (24sp)"),
    EXTRA_LARGE(30, "كبير جداً (30sp)");

    companion object {
        fun fromSp(sp: Int): SubtitleFontSize =
            entries.firstOrNull { it.sp == sp } ?: MEDIUM
    }
}

enum class SubtitleTextColor(val colorArgb: Int, val labelAr: String) {
    WHITE(0xFFFFFFFF.toInt(), "أبيض ناصع"),
    CINEMA_YELLOW(0xFFF5C518.toInt(), "أصفر سينمائي");

    companion object {
        fun fromArgb(argb: Int): SubtitleTextColor =
            entries.firstOrNull { it.colorArgb == argb } ?: WHITE
    }
}

enum class SubtitleBgStyle(val colorArgb: Int, val labelAr: String) {
    NONE(0x00000000, "بدون خلفية"),
    SEMI_TRANSPARENT(0xAA000000.toInt(), "شبه شفاف"),
    SOLID_DARK(0xE6000000.toInt(), "داكن بالكامل");

    companion object {
        fun fromArgb(argb: Int): SubtitleBgStyle =
            entries.firstOrNull { it.colorArgb == argb } ?: SEMI_TRANSPARENT
    }
}

data class FloatSubSettings(
    val deepgramApiKey: String = "",
    val groqApiKey: String = "",
    val geminiApiKey: String = "",
    val sourceLanguage: DeepgramLanguage = DeepgramLanguage.EN,
    val enableOpusCompression: Boolean = true,
    val aiMode: AiTranslationMode = AiTranslationMode.AUTO_HYBRID,
    val fontSize: SubtitleFontSize = SubtitleFontSize.MEDIUM,
    val textColor: SubtitleTextColor = SubtitleTextColor.WHITE,
    val bgStyle: SubtitleBgStyle = SubtitleBgStyle.SEMI_TRANSPARENT,
    val overlayYOffsetPx: Int = DEFAULT_OVERLAY_Y_OFFSET_PX
) {
    companion object {
        const val DEFAULT_OVERLAY_Y_OFFSET_PX = 180
    }
}

class TranslationSettingsStore(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _settingsFlow = MutableStateFlow(loadSettings())
    val settingsFlow: StateFlow<FloatSubSettings> = _settingsFlow.asStateFlow()

    val currentSettings: FloatSubSettings
        get() = _settingsFlow.value

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        _settingsFlow.value = loadSettings()
    }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    private fun loadSettings(): FloatSubSettings {
        val aiModeName = prefs.getString(KEY_AI_MODE, AiTranslationMode.AUTO_HYBRID.name)
        val aiMode = runCatching { AiTranslationMode.valueOf(aiModeName!!) }
            .getOrDefault(AiTranslationMode.AUTO_HYBRID)

        return FloatSubSettings(
            deepgramApiKey = prefs.getString(KEY_DEEPGRAM_API, "")?.trim().orEmpty(),
            groqApiKey = prefs.getString(KEY_GROQ_API, "")?.trim().orEmpty(),
            geminiApiKey = prefs.getString(KEY_GEMINI_API, "")?.trim().orEmpty(),
            sourceLanguage = DeepgramLanguage.fromCode(prefs.getString(KEY_SOURCE_LANG, "en")),
            enableOpusCompression = prefs.getBoolean(KEY_ENABLE_OPUS, true),
            aiMode = aiMode,
            fontSize = SubtitleFontSize.fromSp(prefs.getInt(KEY_FONT_SIZE_SP, 20)),
            textColor = SubtitleTextColor.fromArgb(
                prefs.getInt(KEY_TEXT_COLOR, SubtitleTextColor.WHITE.colorArgb)
            ),
            bgStyle = SubtitleBgStyle.fromArgb(
                prefs.getInt(KEY_BG_STYLE, SubtitleBgStyle.SEMI_TRANSPARENT.colorArgb)
            ),
            overlayYOffsetPx = prefs.getInt(
                KEY_OVERLAY_Y_OFFSET,
                FloatSubSettings.DEFAULT_OVERLAY_Y_OFFSET_PX
            )
        )
    }

    fun updateApiKeys(deepgram: String, groq: String, gemini: String) {
        prefs.edit()
            .putString(KEY_DEEPGRAM_API, deepgram.trim())
            .putString(KEY_GROQ_API, groq.trim())
            .putString(KEY_GEMINI_API, gemini.trim())
            .apply()
    }

    fun updateSourceLanguage(language: DeepgramLanguage) {
        prefs.edit().putString(KEY_SOURCE_LANG, language.code).apply()
    }

    fun updateOpusCompression(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ENABLE_OPUS, enabled).apply()
    }

    fun updateAiMode(mode: AiTranslationMode) {
        prefs.edit().putString(KEY_AI_MODE, mode.name).apply()
    }

    fun updateAppearance(
        fontSize: SubtitleFontSize,
        textColor: SubtitleTextColor,
        bgStyle: SubtitleBgStyle
    ) {
        prefs.edit()
            .putInt(KEY_FONT_SIZE_SP, fontSize.sp)
            .putInt(KEY_TEXT_COLOR, textColor.colorArgb)
            .putInt(KEY_BG_STYLE, bgStyle.colorArgb)
            .apply()
    }

    fun updateOverlayYOffset(offsetPx: Int) {
        prefs.edit().putInt(KEY_OVERLAY_Y_OFFSET, offsetPx.coerceAtLeast(0)).apply()
    }

    fun resetOverlayYOffset() {
        updateOverlayYOffset(FloatSubSettings.DEFAULT_OVERLAY_Y_OFFSET_PX)
    }

    companion object {
        private const val PREFS_NAME = "floatsub_prefs"
        private const val KEY_DEEPGRAM_API = "deepgram_api_key"
        private const val KEY_GROQ_API = "groq_api_key"
        private const val KEY_GEMINI_API = "gemini_api_key"
        private const val KEY_SOURCE_LANG = "source_language"
        private const val KEY_ENABLE_OPUS = "enable_opus_compression"
        private const val KEY_AI_MODE = "ai_translation_mode"
        private const val KEY_FONT_SIZE_SP = "subtitle_font_size_sp"
        private const val KEY_TEXT_COLOR = "subtitle_text_color"
        private const val KEY_BG_STYLE = "subtitle_bg_style"
        private const val KEY_OVERLAY_Y_OFFSET = "overlay_y_offset_px"
    }
}
