package com.floatsub.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.floatsub.app.data.FloatSubSettings
import com.floatsub.app.data.SubtitleBgStyle
import com.floatsub.app.data.TranslationSettingsStore
import kotlin.math.abs
import kotlin.math.roundToInt

enum class BadgeStatus(val colorHex: Int) {
    LISTENING(0xFF22C55E.toInt()),
    PAUSED(0xFFF59E0B.toInt()),
    CONNECTING(0xFF38BDF8.toInt()),
    ERROR(0xFFEF4444.toInt())
}

class FloatingSubtitleWindow(
    private val context: Context,
    private val settingsStore: TranslationSettingsStore,
    private val onTogglePause: () -> Unit,
    private val onClearNow: () -> Unit,
    private val onOpenSettings: () -> Unit,
    private val onCloseService: () -> Unit
) {
    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var subtitleContainer: FrameLayout? = null
    private var subtitleTextView: TextView? = null
    private var subtitleParams: WindowManager.LayoutParams? = null

    private var badgeRootLayout: LinearLayout? = null
    private var statusDotView: View? = null
    private var actionsRowLayout: LinearLayout? = null
    private var pauseResumeBtn: TextView? = null
    private var moveModeBtn: TextView? = null
    private var badgeParams: WindowManager.LayoutParams? = null

    private var isAdded = false
    private var isMenuExpanded = false
    private var isPausedState = false
    private var isMoveSubtitleMode = false
    private var currentSubtitleText: String = ""

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (isAdded || !Settings.canDrawOverlays(context)) return

        val initialSettings = settingsStore.currentSettings

        val subContainer = FrameLayout(context).apply {
            setPadding(dp(16), dp(6), dp(16), dp(6))
        }

        val subText = TextView(context).apply {
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_RTL
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            setLineSpacing(dp(2).toFloat(), 1.05f)
            visibility = View.GONE
        }

        subContainer.addView(
            subText,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val subLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            subtitleFlags(touchable = false),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = initialSettings.overlayYOffsetPx
        }

        var initialSubY = 0
        var initialTouchRawY = 0f
        subContainer.setOnTouchListener { _, event ->
            if (!isMoveSubtitleMode) return@setOnTouchListener false
            val params = subtitleParams ?: return@setOnTouchListener false

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialSubY = params.y
                    initialTouchRawY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaY = (initialTouchRawY - event.rawY).roundToInt()
                    val screenHeight = context.resources.displayMetrics.heightPixels
                    params.y = (initialSubY + deltaY).coerceIn(dp(24), screenHeight - dp(120))
                    runCatching { windowManager.updateViewLayout(subContainer, params) }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    settingsStore.updateOverlayYOffset(params.y)
                    exitMoveSubtitleMode()
                    true
                }
                else -> false
            }
        }

        val badgeRoot = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundedRect(0xD9111827.toInt(), dp(24), 0x55FFFFFF, dp(1))
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }

        val badgePill = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }

        val dot = View(context).apply {
            background = circleDrawable(BadgeStatus.CONNECTING.colorHex)
        }
        badgePill.addView(dot, LinearLayout.LayoutParams(dp(9), dp(9)).apply {
            marginEnd = dp(6)
        })

        val arLabel = TextView(context).apply {
            text = "AR"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
        }
        badgePill.addView(arLabel)

        val actionsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            setPadding(dp(8), 0, 0, 0)
        }

        val btnPause = createActionButton("⏸") {
            onTogglePause()
        }
        val btnClear = createActionButton("⌫") {
            onClearNow()
        }
        val btnMove = createActionButton("✥") {
            toggleMoveSubtitleMode()
        }
        val btnSettings = createActionButton("⚙") {
            setMenuExpanded(false)
            onOpenSettings()
        }
        val btnClose = createActionButton("✕") {
            onCloseService()
        }

        actionsRow.addView(btnPause)
        actionsRow.addView(btnClear)
        actionsRow.addView(btnMove)
        actionsRow.addView(btnSettings)
        actionsRow.addView(btnClose)

        badgeRoot.addView(badgePill)
        badgeRoot.addView(actionsRow)

        val bParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(160)
        }

        var startBadgeX = 0
        var startBadgeY = 0
        var downRawX = 0f
        var downRawY = 0f
        var movedSignificantly = false
        val touchSlopPx = dp(8)

        badgePill.setOnTouchListener { _, event ->
            val params = badgeParams ?: return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startBadgeX = params.x
                    startBadgeY = params.y
                    downRawX = event.rawX
                    downRawY = event.rawY
                    movedSignificantly = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).roundToInt()
                    val dy = (event.rawY - downRawY).roundToInt()
                    if (abs(dx) > touchSlopPx || abs(dy) > touchSlopPx) {
                        movedSignificantly = true
                    }
                    if (movedSignificantly) {
                        params.x = startBadgeX + dx
                        params.y = startBadgeY + dy
                        runCatching { windowManager.updateViewLayout(badgeRoot, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!movedSignificantly) {
                        setMenuExpanded(!isMenuExpanded)
                    }
                    true
                }
                else -> false
            }
        }

        subtitleContainer = subContainer
        subtitleTextView = subText
        subtitleParams = subLayoutParams

        badgeRootLayout = badgeRoot
        statusDotView = dot
        actionsRowLayout = actionsRow
        pauseResumeBtn = btnPause
        moveModeBtn = btnMove
        badgeParams = bParams

        runCatching {
            windowManager.addView(subContainer, subLayoutParams)
            windowManager.addView(badgeRoot, bParams)
            isAdded = true
            applyAppearance(initialSettings)
        }
    }

    private fun toggleMoveSubtitleMode() {
        if (isMoveSubtitleMode) {
            exitMoveSubtitleMode()
        } else {
            enterMoveSubtitleMode()
        }
    }

    private fun enterMoveSubtitleMode() {
        val subContainer = subtitleContainer ?: return
        val params = subtitleParams ?: return
        val subText = subtitleTextView ?: return

        isMoveSubtitleMode = true
        moveModeBtn?.setTextColor(CINEMA_YELLOW_COLOR)

        params.flags = subtitleFlags(touchable = true)
        runCatching { windowManager.updateViewLayout(subContainer, params) }

        subText.text = "↕ اسحب الترجمة للأعلى أو الأسفل ثم أفلت لحفظ المكان"
        subText.visibility = View.VISIBLE
        subContainer.background = roundedRect(0x55F5C518, dp(12), CINEMA_YELLOW_COLOR, dp(1))
    }

    private fun exitMoveSubtitleMode() {
        val subContainer = subtitleContainer ?: return
        val params = subtitleParams ?: return
        val subText = subtitleTextView ?: return

        isMoveSubtitleMode = false
        moveModeBtn?.setTextColor(Color.WHITE)

        params.flags = subtitleFlags(touchable = false)
        subContainer.background = null
        runCatching { windowManager.updateViewLayout(subContainer, params) }

        if (currentSubtitleText.isBlank()) {
            subText.text = ""
            subText.visibility = View.GONE
        } else {
            subText.text = currentSubtitleText
            subText.visibility = View.VISIBLE
        }
    }

    private fun setMenuExpanded(expanded: Boolean) {
        isMenuExpanded = expanded
        actionsRowLayout?.visibility = if (expanded) View.VISIBLE else View.GONE
        badgeRootLayout?.let { root ->
            badgeParams?.let { params ->
                runCatching { windowManager.updateViewLayout(root, params) }
            }
        }
    }

    fun applyAppearance(settings: FloatSubSettings) {
        val subText = subtitleTextView ?: return
        subText.setTextSize(TypedValue.COMPLEX_UNIT_SP, settings.fontSize.sp.toFloat())
        subText.setTextColor(settings.textColor.colorArgb)

        if (settings.bgStyle == SubtitleBgStyle.NONE) {
            subText.background = null
            subText.setShadowLayer(8f, 0f, 3f, Color.BLACK)
        } else {
            subText.background = roundedRect(settings.bgStyle.colorArgb, dp(10))
            subText.setShadowLayer(3f, 0f, 1f, Color.BLACK)
        }

        if (!isMoveSubtitleMode) {
            subtitleParams?.let { params ->
                if (params.y != settings.overlayYOffsetPx) {
                    params.y = settings.overlayYOffsetPx
                    subtitleContainer?.let { view ->
                        runCatching { windowManager.updateViewLayout(view, params) }
                    }
                }
            }
        }
    }

    fun showSubtitle(arabicText: String) {
        currentSubtitleText = arabicText
        if (isMoveSubtitleMode) return

        val subText = subtitleTextView ?: return
        if (arabicText.isBlank()) {
            subText.text = ""
            subText.visibility = View.GONE
        } else {
            subText.text = arabicText
            subText.visibility = View.VISIBLE
        }
    }

    fun clearSubtitle() {
        currentSubtitleText = ""
        if (isMoveSubtitleMode) return
        subtitleTextView?.apply {
            text = ""
            visibility = View.GONE
        }
    }

    fun updateStatus(status: BadgeStatus) {
        statusDotView?.background = circleDrawable(status.colorHex)
        isPausedState = (status == BadgeStatus.PAUSED)
        pauseResumeBtn?.text = if (isPausedState) "▶" else "⏸"
    }

    fun destroy() {
        if (!isAdded) return
        isAdded = false
        subtitleContainer?.let { runCatching { windowManager.removeView(it) } }
        badgeRootLayout?.let { runCatching { windowManager.removeView(it) } }
        subtitleContainer = null
        subtitleTextView = null
        badgeRootLayout = null
    }

    private fun createActionButton(symbol: String, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = symbol
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            gravity = Gravity.CENTER
            setPadding(dp(9), dp(4), dp(9), dp(4))
            setOnClickListener { onClick() }
        }
    }

    private fun subtitleFlags(touchable: Boolean): Int {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (!touchable) {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        return flags
    }

    private fun circleDrawable(fillColor: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fillColor)
        }

    private fun roundedRect(
        fillColor: Int,
        cornerRadiusPx: Int,
        strokeColor: Int = Color.TRANSPARENT,
        strokeWidthPx: Int = 0
    ): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = cornerRadiusPx.toFloat()
        setColor(fillColor)
        if (strokeWidthPx > 0) {
            setStroke(strokeWidthPx, strokeColor)
        }
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).roundToInt()

    companion object {
        private const val CINEMA_YELLOW_COLOR = 0xFFF5C518.toInt()
    }
}
