package com.floatsub.app.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.floatsub.app.audio.AudioCaptureService
import com.floatsub.app.data.TranslationSettingsStore
import com.floatsub.app.player.CinemaPlayerActivity
import com.floatsub.app.translation.ApiKeyCheckResult
import com.floatsub.app.translation.ArabicTranslator
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    private lateinit var settingsStore: TranslationSettingsStore
    private lateinit var keyTesterTranslator: ArabicTranslator

    private var hasOverlayPermissionState by mutableStateOf(false)
    private var isTestingKeysState by mutableStateOf(false)
    private var keyCheckResultsState by mutableStateOf<List<ApiKeyCheckResult>>(emptyList())

    private val pickVideoLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            val fileName = resolveDisplayName(uri)
            startActivity(CinemaPlayerActivity.createIntent(this, uri, fileName))
        }
    }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        hasOverlayPermissionState = Settings.canDrawOverlays(this)
    }

    private val runtimePermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val audioGranted = grants[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

        if (audioGranted) {
            launchMediaProjectionPrompt()
        } else {
            Toast.makeText(
                this,
                "يلزم منح إذن الصوت لالتقاط صوت الفيديو الداخلي",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, AudioCaptureService::class.java).apply {
                action = AudioCaptureService.ACTION_START
                putExtra(AudioCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(AudioCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            moveTaskToBack(true)
        } else {
            Toast.makeText(this, "تم إلغاء إذن التقاط صوت الشاشة", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settingsStore = TranslationSettingsStore(this)
        val okHttp = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
        keyTesterTranslator = ArabicTranslator(this, settingsStore, okHttp)

        hasOverlayPermissionState = Settings.canDrawOverlays(this)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val settings by settingsStore.settingsFlow.collectAsState()
                val isServiceRunning by AudioCaptureService.isRunningFlow.collectAsState()

                FloatSubScreen(
                    settings = settings,
                    isServiceRunning = isServiceRunning,
                    hasOverlayPermission = hasOverlayPermissionState,
                    isTestingKeys = isTestingKeysState,
                    keyCheckResults = keyCheckResultsState,
                    onSaveApiKeys = { dg, groq, gemini ->
                        settingsStore.updateApiKeys(dg, groq, gemini)
                    },
                    onTestApiKeys = { dg, groq, gemini ->
                        settingsStore.updateApiKeys(dg, groq, gemini)
                        runApiKeyVerification()
                    },
                    onSelectLanguage = { settingsStore.updateSourceLanguage(it) },
                    onToggleOpus = { settingsStore.updateOpusCompression(it) },
                    onSelectAiMode = { settingsStore.updateAiMode(it) },
                    onUpdateAppearance = { size, color, bg ->
                        settingsStore.updateAppearance(size, color, bg)
                    },
                    onResetOverlayPosition = { settingsStore.resetOverlayYOffset() },
                    onUpdateCinemaSettings = { leadMs, preBuffer ->
                        settingsStore.updateCinemaSettings(leadMs, preBuffer)
                    },
                    onPickLocalVideoForCinema = {
                        pickVideoLauncher.launch(arrayOf("video/*"))
                    },
                    onPlayStreamUrlInCinema = { rawUrl ->
                        val cleanUrl = rawUrl.trim()
                        if (cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://")) {
                            settingsStore.updateLastStreamUrl(cleanUrl)
                            startActivity(
                                CinemaPlayerActivity.createIntent(
                                    this,
                                    Uri.parse(cleanUrl),
                                    "بث مباشر سينمائي"
                                )
                            )
                        } else {
                            Toast.makeText(
                                this,
                                "يرجى إدخال رابط يبدأ بـ https:// أو http://",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    onRequestOverlayPermission = { openOverlayPermissionSettings() },
                    onStartCaptureClick = { checkPermissionsAndStartCapture() },
                    onStopCaptureClick = { stopCaptureService() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hasOverlayPermissionState = Settings.canDrawOverlays(this)
    }

    override fun onDestroy() {
        keyTesterTranslator.close()
        super.onDestroy()
    }

    private fun resolveDisplayName(uri: Uri): String {
        return runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
        }.getOrNull().orEmpty()
    }

    private fun runApiKeyVerification() {
        if (isTestingKeysState) return
        isTestingKeysState = true
        lifecycleScope.launch {
            try {
                val results = keyTesterTranslator.verifyAllConfiguredKeys()
                keyCheckResultsState = if (results.isEmpty()) {
                    listOf(
                        ApiKeyCheckResult(
                            provider = "تنبيه",
                            isValid = false,
                            message = "لم يتم إدخال أي مفتاح سحابي (سيتم استخدام الوضع الأوفلاين)"
                        )
                    )
                } else {
                    results
                }
            } finally {
                isTestingKeysState = false
            }
        }
    }

    private fun openOverlayPermissionSettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        overlayPermissionLauncher.launch(intent)
    }

    private fun checkPermissionsAndStartCapture() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlayPermissionSettings()
            return
        }

        val neededPermissions = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            neededPermissions.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            neededPermissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (neededPermissions.isNotEmpty()) {
            runtimePermissionsLauncher.launch(neededPermissions.toTypedArray())
        } else {
            launchMediaProjectionPrompt()
        }
    }

    private fun launchMediaProjectionPrompt() {
        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun stopCaptureService() {
        val stopIntent = Intent(this, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_STOP
        }
        startService(stopIntent)
    }
}
