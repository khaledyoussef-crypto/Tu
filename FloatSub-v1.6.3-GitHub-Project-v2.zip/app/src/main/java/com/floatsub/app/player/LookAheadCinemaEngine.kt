package com.floatsub.app.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.floatsub.app.audio.VoskModelManager
import com.floatsub.app.data.TranslationSettingsStore
import com.floatsub.app.translation.ArabicTranslator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.ConnectionPool
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.util.ArrayDeque
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume
import kotlin.math.abs

data class TimedSubtitleCue(
    val speechStartMs: Long,
    val speechEndMs: Long,
    val arabicText: String,
    val isFinal: Boolean
)

sealed class VideoQualityOption(val id: String, val labelAr: String) {
    data object Auto : VideoQualityOption("auto", "تلقائي (Auto)")

    data class TrackVariant(
        val groupIndex: Int,
        val trackIndex: Int,
        val width: Int,
        val height: Int,
        val bitrate: Int,
        val displayLabel: String
    ) : VideoQualityOption("track_${groupIndex}_$trackIndex", displayLabel)

    data class ResolutionCap(
        val maxWidth: Int,
        val maxHeight: Int,
        val displayLabel: String
    ) : VideoQualityOption("cap_${maxHeight}p", displayLabel)
}

data class CinemaPlayerUiState(
    val mediaTitle: String = "المشغل السينمائي المسبق",
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val isPreTranslating: Boolean = false,
    val preTranslateProgress: Float = 0f,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val bufferedPositionMs: Long = 0L,
    val lookAheadLeadMs: Long = 0L,
    val activeSubtitle: String = "",
    val translatedCueCount: Int = 0,
    val availableQualities: List<VideoQualityOption> = listOf(VideoQualityOption.Auto),
    val selectedQualityId: String = "auto",
    val activeResolutionLabel: String = "Auto",
    val playbackSpeed: Float = 1.0f,
    val errorMessage: String? = null
)

@OptIn(UnstableApi::class)
class LookAheadCinemaEngine(
    context: Context,
    private val settingsStore: TranslationSettingsStore
) {
    private val appContext = context.applicationContext
    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val okHttpClient = OkHttpClient.Builder()
        .connectionPool(ConnectionPool(6, 5, TimeUnit.MINUTES))
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val translator = ArabicTranslator(appContext, settingsStore, okHttpClient)
    private val voskModelManager = VoskModelManager(appContext, okHttpClient)

    private val _uiState = MutableStateFlow(CinemaPlayerUiState())
    val uiState: StateFlow<CinemaPlayerUiState> = _uiState.asStateFlow()

    private val cues = CopyOnWriteArrayList<TimedSubtitleCue>()

    private sealed class ScoutAudioEvent {
        data class SeekReset(val targetMediaMs: Long, val epoch: Int) : ScoutAudioEvent()
        data class AudioChunk(
            val pcm16k: ByteArray,
            val mediaStartMs: Long,
            val durationMs: Long,
            val epoch: Int
        ) : ScoutAudioEvent()
    }

    private val audioChannel = Channel<ScoutAudioEvent>(
        capacity = 320,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    private val currentSeekEpoch = AtomicInteger(0)
    private val latestScoutPosMs = AtomicLong(0L)
    private val pendingSeekAnchorMs = AtomicLong(0L)

    // حقول خاصة بمستقبل الصوت TeeAudioProcessor
    @Volatile
    private var sinkSampleRate = 48000

    @Volatile
    private var sinkChannels = 2

    @Volatile
    private var sinkEncoding = C.ENCODING_PCM_16BIT

    private var flushAnchorMediaMs = 0L
    private var samplesSinceFlush16k = 0L

    private val teeAudioProcessor = TeeAudioProcessor(object : TeeAudioProcessor.AudioBufferSink {
        override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
            sinkSampleRate = sampleRateHz
            sinkChannels = channelCount
            sinkEncoding = encoding
            samplesSinceFlush16k = 0L
            val explicitTarget = pendingSeekAnchorMs.getAndSet(-1L)
            flushAnchorMediaMs = if (explicitTarget >= 0L) {
                explicitTarget
            } else {
                latestScoutPosMs.get()
            }
        }

        override fun handleBuffer(buffer: ByteBuffer) {
            val dup = buffer.duplicate()
            val rem = dup.remaining()
            if (rem <= 0) return

            val raw = ByteArray(rem)
            dup.get(raw)

            val pcm16k = PcmResampler.to16kMono16Bit(
                rawBytes = raw,
                sampleRateHz = sinkSampleRate,
                channelCount = sinkChannels,
                encoding = sinkEncoding
            )
            if (pcm16k.isEmpty()) return

            val sampleCount16k = (pcm16k.size / 2).toLong()
            val chunkMediaStartMs = flushAnchorMediaMs + (samplesSinceFlush16k * 1000L) / 16000L
            val chunkDurationMs = (sampleCount16k * 1000L) / 16000L
            samplesSinceFlush16k += sampleCount16k

            audioChannel.trySend(
                ScoutAudioEvent.AudioChunk(
                    pcm16k = pcm16k,
                    mediaStartMs = chunkMediaStartMs,
                    durationMs = chunkDurationMs,
                    epoch = currentSeekEpoch.get()
                )
            )
        }
    })

    val mainPlayer: ExoPlayer
    private val scoutPlayer: ExoPlayer

    private var userWantsPlay: Boolean = true
    private var isPreBufferingNow: Boolean = false
    private var preBufferOriginMs: Long = 0L

    private var tickerJob: Job? = null
    private var transcriptionJob: Job? = null

    init {
        val httpDataSourceFactory = OkHttpDataSource.Factory(okHttpClient)
            .setUserAgent(USER_AGENT)
        val dataSourceFactory = DefaultDataSource.Factory(appContext, httpDataSourceFactory)
        val mainMediaSourceFactory =
            DefaultMediaSourceFactory(appContext).setDataSourceFactory(dataSourceFactory)
        val scoutMediaSourceFactory =
            DefaultMediaSourceFactory(appContext).setDataSourceFactory(dataSourceFactory)

        mainPlayer = ExoPlayer.Builder(appContext)
            .setMediaSourceFactory(mainMediaSourceFactory)
            .build()

        val scoutRenderersFactory = object : DefaultRenderersFactory(appContext) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(false)
                    .setEnableAudioTrackPlaybackParams(false)
                    .setAudioProcessors(arrayOf(teeAudioProcessor))
                    .build()
            }
        }

        scoutPlayer = ExoPlayer.Builder(appContext, scoutRenderersFactory)
            .setMediaSourceFactory(scoutMediaSourceFactory)
            .build().apply {
                volume = 0f
                trackSelectionParameters = trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
                    .build()
            }

        setupMainPlayerListeners()
        startMainSyncTicker()
        startLookAheadTranscriptionWorker()
    }

    private fun setupMainPlayerListeners() {
        mainPlayer.addListener(object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) {
                refreshAvailableVideoQualities(tracks)
            }

            override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                if (videoSize.height > 0) {
                    val badge = "${videoSize.height}p"
                    _uiState.value = _uiState.value.copy(activeResolutionLabel = badge)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                _uiState.value = _uiState.value.copy(
                    errorMessage = "تعذر تشغيل المصدر: ${error.localizedMessage ?: error.errorCodeName}"
                )
            }
        })
    }

    fun loadMedia(uri: Uri, title: String = "") {
        cues.clear()
        translator.clearSceneHistory()
        val displayTitle = title.ifBlank {
            uri.lastPathSegment?.substringAfterLast('/') ?: "فيديو سينمائي"
        }

        val epoch = currentSeekEpoch.incrementAndGet()
        pendingSeekAnchorMs.set(0L)
        latestScoutPosMs.set(0L)
        audioChannel.trySend(ScoutAudioEvent.SeekReset(0L, epoch))

        val mediaItem = MediaItem.fromUri(uri)
        mainPlayer.setMediaItem(mediaItem)
        scoutPlayer.setMediaItem(mediaItem)

        mainPlayer.prepare()
        scoutPlayer.prepare()

        userWantsPlay = true
        _uiState.value = _uiState.value.copy(
            mediaTitle = displayTitle,
            errorMessage = null,
            activeSubtitle = "",
            translatedCueCount = 0,
            selectedQualityId = "auto"
        )

        if (settingsStore.currentSettings.cinemaPreBufferOnSeek) {
            beginPreTranslationHold(originMs = 0L)
        } else {
            isPreBufferingNow = false
            mainPlayer.play()
            scoutPlayer.play()
        }
    }

    fun togglePlayPause() {
        if (isPreBufferingNow) {
            // إذا ضغط المستخدم إيقاف أثناء التجهيز المسبق
            isPreBufferingNow = false
            userWantsPlay = false
            mainPlayer.pause()
            scoutPlayer.pause()
            return
        }

        if (mainPlayer.isPlaying) {
            userWantsPlay = false
            mainPlayer.pause()
            scoutPlayer.pause()
        } else {
            if (mainPlayer.playbackState == Player.STATE_ENDED) {
                seekTo(0L)
            }
            userWantsPlay = true
            mainPlayer.play()
            scoutPlayer.play()
        }
    }

    fun skipPreBufferNow() {
        if (!isPreBufferingNow) return
        isPreBufferingNow = false
        _uiState.value = _uiState.value.copy(isPreTranslating = false, preTranslateProgress = 1f)
        if (userWantsPlay) {
            mainPlayer.play()
        }
    }

    fun seekBy(deltaMs: Long) {
        val duration = mainPlayer.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: Long.MAX_VALUE
        val target = (mainPlayer.currentPosition + deltaMs).coerceIn(0L, duration)
        seekTo(target)
    }

    fun seekTo(positionMs: Long) {
        val duration = mainPlayer.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: Long.MAX_VALUE
        val clamped = positionMs.coerceIn(0L, duration)

        val epoch = currentSeekEpoch.incrementAndGet()
        pendingSeekAnchorMs.set(clamped)
        latestScoutPosMs.set(clamped)
        audioChannel.trySend(ScoutAudioEvent.SeekReset(clamped, epoch))

        mainPlayer.seekTo(clamped)
        scoutPlayer.seekTo(clamped)

        // إذا كانت هذه المنطقة مترجمة مسبقاً في الذاكرة، شغل فوراً بدون انتظار!
        val alreadyTranslated = hasTranslatedCuesInWindow(clamped, clamped + 4500L)

        if (userWantsPlay && settingsStore.currentSettings.cinemaPreBufferOnSeek && !alreadyTranslated) {
            beginPreTranslationHold(originMs = clamped)
        } else {
            isPreBufferingNow = false
            _uiState.value = _uiState.value.copy(isPreTranslating = false)
            if (userWantsPlay) {
                mainPlayer.play()
                scoutPlayer.play()
            }
        }
    }

    private fun beginPreTranslationHold(originMs: Long) {
        isPreBufferingNow = true
        preBufferOriginMs = originMs
        mainPlayer.pause()
        scoutPlayer.playbackParameters = PlaybackParameters(1.75f)
        scoutPlayer.play()
        _uiState.value = _uiState.value.copy(
            isPreTranslating = true,
            preTranslateProgress = 0.05f
        )
    }

    fun setPlaybackSpeed(speed: Float) {
        val safeSpeed = speed.coerceIn(0.5f, 2.0f)
        mainPlayer.playbackParameters = PlaybackParameters(safeSpeed)
        _uiState.value = _uiState.value.copy(playbackSpeed = safeSpeed)
    }

    fun selectQuality(option: VideoQualityOption) {
        when (option) {
            is VideoQualityOption.Auto -> {
                mainPlayer.trackSelectionParameters = mainPlayer.trackSelectionParameters
                    .buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                    .clearVideoSizeConstraints()
                    .build()
            }
            is VideoQualityOption.TrackVariant -> {
                val videoGroups = mainPlayer.currentTracks.groups
                    .filter { it.type == C.TRACK_TYPE_VIDEO }
                val targetGroup = videoGroups.getOrNull(option.groupIndex)
                if (targetGroup != null && option.trackIndex in 0 until targetGroup.length) {
                    mainPlayer.trackSelectionParameters = mainPlayer.trackSelectionParameters
                        .buildUpon()
                        .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                        .clearVideoSizeConstraints()
                        .addOverride(
                            TrackSelectionOverride(
                                targetGroup.mediaTrackGroup,
                                listOf(option.trackIndex)
                            )
                        )
                        .build()
                }
            }
            is VideoQualityOption.ResolutionCap -> {
                mainPlayer.trackSelectionParameters = mainPlayer.trackSelectionParameters
                    .buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                    .setMaxVideoSize(option.maxWidth, option.maxHeight)
                    .build()
            }
        }
        _uiState.value = _uiState.value.copy(selectedQualityId = option.id)
    }

    private fun refreshAvailableVideoQualities(tracks: Tracks) {
        val options = ArrayList<VideoQualityOption>()
        options.add(VideoQualityOption.Auto)

        val videoGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_VIDEO }
        val discoveredVariants = ArrayList<VideoQualityOption.TrackVariant>()

        videoGroups.forEachIndexed { groupIdx, group ->
            for (trackIdx in 0 until group.length) {
                if (!group.isTrackSupported(trackIdx)) continue
                val fmt = group.getTrackFormat(trackIdx)
                if (fmt.height > 0) {
                    val bitrateStr = if (fmt.bitrate > 0) {
                        val mbps = fmt.bitrate / 1_000_000.0
                        if (mbps >= 1.0) String.format(Locale.US, " • %.1f Mbps", mbps)
                        else " • ${fmt.bitrate / 1000} kbps"
                    } else ""
                    val tag = when {
                        fmt.height >= 1080 -> "FHD"
                        fmt.height >= 720 -> "HD"
                        else -> "SD"
                    }
                    discoveredVariants.add(
                        VideoQualityOption.TrackVariant(
                            groupIndex = groupIdx,
                            trackIndex = trackIdx,
                            width = fmt.width,
                            height = fmt.height,
                            bitrate = fmt.bitrate,
                            displayLabel = "${fmt.height}p $tag$bitrateStr"
                        )
                    )
                }
            }
        }

        val sortedUniqueVariants = discoveredVariants
            .sortedWith(compareByDescending<VideoQualityOption.TrackVariant> { it.height }.thenByDescending { it.bitrate })
            .distinctBy { "${it.height}_${it.bitrate / 100_000}" }

        if (sortedUniqueVariants.size > 1) {
            options.addAll(sortedUniqueVariants)
        } else {
            // إضافة حدود دقة قياسية مفيدة للبث التكيفي وتوفير البيانات
            options.add(VideoQualityOption.ResolutionCap(1920, 1080, "أعلى جودة (حتى 1080p FHD)"))
            options.add(VideoQualityOption.ResolutionCap(1280, 720, "جودة متوسطة (720p HD)"))
            options.add(VideoQualityOption.ResolutionCap(854, 480, "توفير البيانات (480p SD)"))
            options.add(VideoQualityOption.ResolutionCap(640, 360, "إنترنت ضعيف (360p)"))
        }

        _uiState.value = _uiState.value.copy(availableQualities = options)
    }

    // =========================================================================
    // حلقة المزامنة الدقيقة (كل 60ms على الـ Main Thread)
    // =========================================================================

    private fun startMainSyncTicker() {
        tickerJob?.cancel()
        tickerJob = mainScope.launch {
            while (isActive) {
                val mainPos = mainPlayer.currentPosition.coerceAtLeast(0L)
                val scoutPos = scoutPlayer.currentPosition.coerceAtLeast(0L)
                latestScoutPosMs.set(scoutPos)

                val duration = mainPlayer.duration.let { if (it == C.TIME_UNSET || it < 0L) 0L else it }
                val buffered = mainPlayer.bufferedPosition.coerceAtLeast(0L)
                val leadMs = (scoutPos - mainPos).coerceAtLeast(0L)

                syncScoutLead(mainPos, scoutPos, duration)

                val subtitleLeadSetting = settingsStore.currentSettings.cinemaLeadTimeMs
                val activeCueText = findActiveSubtitle(mainPos, subtitleLeadSetting)

                _uiState.value = _uiState.value.copy(
                    isPlaying = mainPlayer.isPlaying || isPreBufferingNow,
                    isBuffering = mainPlayer.playbackState == Player.STATE_BUFFERING,
                    isPreTranslating = isPreBufferingNow,
                    currentPositionMs = mainPos,
                    durationMs = duration,
                    bufferedPositionMs = buffered,
                    lookAheadLeadMs = leadMs,
                    activeSubtitle = activeCueText,
                    translatedCueCount = cues.size
                )

                delay(60L)
            }
        }
    }

    private fun syncScoutLead(mainPos: Long, scoutPos: Long, duration: Long) {
        if (isPreBufferingNow) {
            val builtLead = scoutPos - preBufferOriginMs
            val progress = (builtLead.toFloat() / PREBUFFER_TARGET_LEAD_MS.toFloat()).coerceIn(0f, 1f)
            _uiState.value = _uiState.value.copy(preTranslateProgress = progress)

            val reachedEnd = scoutPlayer.playbackState == Player.STATE_ENDED ||
                (duration > 0L && scoutPos >= duration - 500L)

            if (builtLead >= PREBUFFER_TARGET_LEAD_MS || reachedEnd) {
                isPreBufferingNow = false
                _uiState.value = _uiState.value.copy(isPreTranslating = false, preTranslateProgress = 1f)
                if (userWantsPlay) {
                    mainPlayer.play()
                }
            } else if (!scoutPlayer.isPlaying && scoutPlayer.playbackState == Player.STATE_READY) {
                scoutPlayer.play()
            }
            return
        }

        if (!userWantsPlay || !mainPlayer.isPlaying) {
            if (scoutPlayer.isPlaying) {
                scoutPlayer.pause()
            }
            return
        }

        if (scoutPlayer.playbackState == Player.STATE_ENDED) return

        val diff = scoutPos - mainPos
        val mainSpeed = mainPlayer.playbackParameters.speed

        when {
            diff < -400L || diff > 20_000L -> {
                pendingSeekAnchorMs.set(mainPos)
                scoutPlayer.seekTo(mainPos)
                scoutPlayer.playbackParameters = PlaybackParameters((mainSpeed * 1.65f).coerceAtMost(2.0f))
                scoutPlayer.play()
            }
            diff < TARGET_SCOUT_LEAD_MIN_MS -> {
                val catchUpSpeed = (mainSpeed * 1.6f).coerceAtMost(2.0f)
                if (abs(scoutPlayer.playbackParameters.speed - catchUpSpeed) > 0.05f) {
                    scoutPlayer.playbackParameters = PlaybackParameters(catchUpSpeed)
                }
                if (!scoutPlayer.isPlaying) scoutPlayer.play()
            }
            diff in TARGET_SCOUT_LEAD_MIN_MS..TARGET_SCOUT_LEAD_MAX_MS -> {
                if (abs(scoutPlayer.playbackParameters.speed - mainSpeed) > 0.05f) {
                    scoutPlayer.playbackParameters = PlaybackParameters(mainSpeed)
                }
                if (!scoutPlayer.isPlaying) scoutPlayer.play()
            }
            diff > TARGET_SCOUT_LEAD_PAUSE_MS -> {
                if (scoutPlayer.isPlaying) {
                    scoutPlayer.pause()
                }
            }
        }
    }

    private fun findActiveSubtitle(mainPosMs: Long, leadTimeMs: Long): String {
        // يظهر السطر عندما يصل المشهد إلى (بداية النطق - leadTimeMs) مثل الأفلام المترجمة تماماً
        var chosen: TimedSubtitleCue? = null
        for (cue in cues) {
            val displayStart = (cue.speechStartMs - leadTimeMs).coerceAtLeast(0L)
            val displayEnd = cue.speechEndMs + 350L
            if (mainPosMs in displayStart..displayEnd) {
                if (chosen == null || cue.speechStartMs >= chosen.speechStartMs) {
                    chosen = cue
                }
            }
        }
        return chosen?.arabicText.orEmpty()
    }

    private fun hasTranslatedCuesInWindow(startMs: Long, endMs: Long): Boolean {
        return cues.any { it.isFinal && it.speechEndMs >= startMs && it.speechStartMs <= endMs }
    }

    private fun upsertSubtitleCue(newCue: TimedSubtitleCue) {
        if (newCue.arabicText.isBlank()) return

        // عدم الكتابة فوق جملة نهائية موجودة بجملة جزئية (interim)
        if (!newCue.isFinal) {
            val hasFinalAlready = cues.any { existing ->
                existing.isFinal && abs(existing.speechStartMs - newCue.speechStartMs) < 900L
            }
            if (hasFinalAlready) return
        }

        val toRemove = ArrayList<TimedSubtitleCue>()
        for (existing in cues) {
            val sameWindow = abs(existing.speechStartMs - newCue.speechStartMs) < 850L
            val interimOverlap = !existing.isFinal &&
                existing.speechStartMs <= newCue.speechEndMs &&
                existing.speechEndMs >= newCue.speechStartMs
            if (sameWindow || interimOverlap) {
                toRemove.add(existing)
            }
        }
        if (toRemove.isNotEmpty()) {
            cues.removeAll(toRemove.toSet())
        }
        cues.add(newCue)
    }

    // =========================================================================
    // محرك التفريغ الصوتي المسبق والترجمة السينمائية على الخلفية
    // =========================================================================

    private fun startLookAheadTranscriptionWorker() {
        transcriptionJob?.cancel()
        transcriptionJob = ioScope.launch {
            val settings = settingsStore.currentSettings
            when {
                settings.deepgramApiKey.isNotBlank() -> runDeepgramLookAheadLoop()
                settings.groqApiKey.isNotBlank() -> runWhisperLookAheadLoop()
                else -> runVoskLookAheadLoop()
            }
        }
    }

    private data class StreamSegmentMap(
        val streamOffsetMs: Long,
        val mediaOriginMs: Long
    )

    private suspend fun runDeepgramLookAheadLoop() {
        while (ioScope.isActive) {
            val apiKey = settingsStore.currentSettings.deepgramApiKey
            if (apiKey.isBlank()) {
                delay(1000L)
                continue
            }

            try {
                runSingleDeepgramLookAheadSession(apiKey)
            } catch (ce: CancellationException) {
                throw ce
            } catch (_: Exception) {
                delay(1200L)
            }
        }
    }

    private suspend fun runSingleDeepgramLookAheadSession(apiKey: String) {
        val langCode = settingsStore.currentSettings.sourceLanguage.code
        val url = "wss://api.deepgram.com/v1/listen" +
            "?model=nova-2" +
            "&language=$langCode" +
            "&smart_format=true" +
            "&punctuate=true" +
            "&interim_results=true" +
            "&endpointing=120" +
            "&utterance_end_ms=1000" +
            "&vad_events=true" +
            "&encoding=linear16&sample_rate=16000&channels=1"

        val segmentMaps = ArrayDeque<StreamSegmentMap>()
        val mapLock = Any()
        val socketOpen = AtomicBoolean(false)
        val socketFailed = AtomicBoolean(false)

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Token $apiKey")
            .build()

        val ws = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                socketOpen.set(true)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val root = runCatching { JSONObject(text) }.getOrNull() ?: return
                if (root.optString("type") != "Results") return

                val isFinal = root.optBoolean("is_final", false)
                val transcript = root.optJSONObject("channel")
                    ?.optJSONArray("alternatives")
                    ?.optJSONObject(0)
                    ?.optString("transcript", "")
                    ?.trim()
                    .orEmpty()

                if (transcript.isBlank() || translator.isWhisperOrSubtitleHallucination(transcript)) {
                    return
                }

                val startSec = root.optDouble("start", 0.0)
                val durationSec = root.optDouble("duration", 1.6)
                val streamStartMs = (startSec * 1000.0).toLong()

                val anchor = synchronized(mapLock) {
                    segmentMaps.lastOrNull { it.streamOffsetMs <= streamStartMs + 150L }
                        ?: segmentMaps.lastOrNull()
                } ?: return

                val mediaStartMs =
                    anchor.mediaOriginMs + (streamStartMs - anchor.streamOffsetMs).coerceAtLeast(0L)
                val mediaEndMs =
                    mediaStartMs + (durationSec * 1000.0).toLong().coerceIn(900L, 6500L)

                if (isFinal && hasTranslatedCuesInWindow(mediaStartMs + 200L, mediaEndMs - 200L)) {
                    return
                }

                ioScope.launch {
                    val arabic = translator.translate(
                        rawSourceText = transcript,
                        isFinal = isFinal,
                        aiTimeoutMs = ArabicTranslator.CINEMA_AI_TIMEOUT_MS
                    )
                    if (arabic.isNotBlank()) {
                        upsertSubtitleCue(
                            TimedSubtitleCue(
                                speechStartMs = mediaStartMs,
                                speechEndMs = mediaEndMs,
                                arabicText = arabic,
                                isFinal = isFinal
                            )
                        )
                    }
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                socketOpen.set(false)
                socketFailed.set(true)
                webSocket.close(1000, null)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                socketOpen.set(false)
                socketFailed.set(true)
            }
        })

        var totalStreamSentMs = 0L
        var expectedNextMediaMs = -1L
        var lastKeepAliveMs = System.currentTimeMillis()
        val silenceFlushBytes = ByteArray(16000) // 500ms صمت عند التقديم أو التأخير لفصل الجمل بدقة

        try {
            while (ioScope.isActive && !socketFailed.get()) {
                val now = System.currentTimeMillis()
                if (socketOpen.get() && now - lastKeepAliveMs >= 7500L) {
                    ws.send("""{"type":"KeepAlive"}""")
                    lastKeepAliveMs = now
                }

                val event = audioChannel.tryReceive().getOrNull()
                if (event == null) {
                    delay(20L)
                    continue
                }

                when (event) {
                    is ScoutAudioEvent.SeekReset -> {
                        if (socketOpen.get()) {
                            ws.send(silenceFlushBytes.toByteString())
                            totalStreamSentMs += 500L
                        }
                        synchronized(mapLock) {
                            segmentMaps.addLast(StreamSegmentMap(totalStreamSentMs, event.targetMediaMs))
                            while (segmentMaps.size > 40) segmentMaps.removeFirst()
                        }
                        expectedNextMediaMs = event.targetMediaMs
                    }
                    is ScoutAudioEvent.AudioChunk -> {
                        if (!socketOpen.get()) continue
                        if (event.epoch != currentSeekEpoch.get()) continue

                        if (expectedNextMediaMs < 0L || abs(event.mediaStartMs - expectedNextMediaMs) > 650L) {
                            ws.send(silenceFlushBytes.toByteString())
                            totalStreamSentMs += 500L
                            synchronized(mapLock) {
                                segmentMaps.addLast(StreamSegmentMap(totalStreamSentMs, event.mediaStartMs))
                                while (segmentMaps.size > 40) segmentMaps.removeFirst()
                            }
                        }

                        ws.send(event.pcm16k.toByteString())
                        totalStreamSentMs += event.durationMs
                        expectedNextMediaMs = event.mediaStartMs + event.durationMs
                    }
                }
            }
        } finally {
            runCatching { ws.send("""{"type":"CloseStream"}""") }
            runCatching { ws.close(1000, "Done") }
        }
    }

    private suspend fun runWhisperLookAheadLoop() {
        val speechBuffer = ByteArrayOutputStream()
        var isSpeaking = false
        var segmentMediaStartMs = 0L
        var speechDurationMs = 0L
        var silenceDurationMs = 0L
        var activeEpoch = currentSeekEpoch.get()

        while (ioScope.isActive) {
            val event = audioChannel.receive()
            when (event) {
                is ScoutAudioEvent.SeekReset -> {
                    speechBuffer.reset()
                    isSpeaking = false
                    speechDurationMs = 0L
                    silenceDurationMs = 0L
                    activeEpoch = event.epoch
                }
                is ScoutAudioEvent.AudioChunk -> {
                    if (event.epoch != currentSeekEpoch.get()) continue
                    if (event.epoch != activeEpoch) {
                        speechBuffer.reset()
                        isSpeaking = false
                        speechDurationMs = 0L
                        silenceDurationMs = 0L
                        activeEpoch = event.epoch
                    }

                    val rms = PcmResampler.computeRms16Bit(event.pcm16k)
                    if (!isSpeaking) {
                        if (rms >= 260.0) {
                            isSpeaking = true
                            segmentMediaStartMs = event.mediaStartMs
                            speechDurationMs = event.durationMs
                            silenceDurationMs = 0L
                            speechBuffer.write(event.pcm16k)
                        }
                    } else {
                        speechBuffer.write(event.pcm16k)
                        speechDurationMs += event.durationMs
                        if (rms < 260.0) silenceDurationMs += event.durationMs else silenceDurationMs = 0L

                        val naturalPause = speechDurationMs >= 850L && silenceDurationMs >= 240L
                        val maxLen = speechDurationMs >= 2400L

                        if (naturalPause || maxLen) {
                            val pcmSegment = speechBuffer.toByteArray()
                            val segStart = segmentMediaStartMs
                            val segEnd = event.mediaStartMs + event.durationMs
                            val chunkEpoch = event.epoch

                            speechBuffer.reset()
                            isSpeaking = false
                            speechDurationMs = 0L
                            silenceDurationMs = 0L

                            if (!hasTranslatedCuesInWindow(segStart + 200L, segEnd - 200L)) {
                                ioScope.launch {
                                    val transcript = transcribeChunkWithGroqWhisper(pcmSegment)
                                    if (!transcript.isNullOrBlank() &&
                                        !translator.isWhisperOrSubtitleHallucination(transcript) &&
                                        chunkEpoch == currentSeekEpoch.get()
                                    ) {
                                        val arabic = translator.translate(
                                            rawSourceText = transcript,
                                            isFinal = true,
                                            aiTimeoutMs = ArabicTranslator.CINEMA_AI_TIMEOUT_MS
                                        )
                                        if (arabic.isNotBlank()) {
                                            upsertSubtitleCue(
                                                TimedSubtitleCue(
                                                    speechStartMs = segStart,
                                                    speechEndMs = segEnd.coerceAtLeast(segStart + 1100L),
                                                    arabicText = arabic,
                                                    isFinal = true
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private suspend fun transcribeChunkWithGroqWhisper(pcmBytes: ByteArray): String? {
        val groqKey = settingsStore.currentSettings.groqApiKey
        if (groqKey.isBlank()) return null

        val wavBytes = PcmResampler.pcm16MonoToWav(pcmBytes, 16000)
        val lang = settingsStore.currentSettings.sourceLanguage.code

        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", "cinema.wav", wavBytes.toRequestBody("audio/wav".toMediaType()))
            .addFormDataPart("model", "whisper-large-v3-turbo")
            .addFormDataPart("response_format", "json")
            .addFormDataPart("temperature", "0")
            .apply {
                if (lang != "multi") addFormDataPart("language", lang.substringBefore("-"))
            }
            .build()

        val request = Request.Builder()
            .url("https://api.groq.com/openai/v1/audio/transcriptions")
            .addHeader("Authorization", "Bearer $groqKey")
            .post(multipart)
            .build()

        return suspendCancellableCoroutine { cont ->
            val call = okHttpClient.newCall(request)
            cont.invokeOnCancellation { call.cancel() }
            call.enqueue(object : okhttp3.Callback {
                override fun onFailure(call: okhttp3.Call, e: IOException) {
                    if (cont.isActive) cont.resume(null)
                }

                override fun onResponse(call: okhttp3.Call, response: Response) {
                    response.use { res ->
                        if (!res.isSuccessful) {
                            if (cont.isActive) cont.resume(null)
                            return
                        }
                        val txt = runCatching {
                            JSONObject(res.body?.string().orEmpty()).optString("text", "").trim()
                        }.getOrNull()
                        if (cont.isActive) cont.resume(txt)
                    }
                }
            })
        }
    }

    private suspend fun runVoskLookAheadLoop() {
        val model = runCatching { voskModelManager.ensureModelLoaded() }.getOrNull() ?: return
        val recognizer = Recognizer(model, 16000f)
        var utteranceStartMs = -1L

        try {
            while (ioScope.isActive) {
                val event = audioChannel.receive()
                when (event) {
                    is ScoutAudioEvent.SeekReset -> {
                        recognizer.reset()
                        utteranceStartMs = -1L
                    }
                    is ScoutAudioEvent.AudioChunk -> {
                        if (event.epoch != currentSeekEpoch.get()) continue
                        if (utteranceStartMs < 0L) utteranceStartMs = event.mediaStartMs

                        val isFinal = recognizer.acceptWaveForm(event.pcm16k, event.pcm16k.size)
                        if (isFinal) {
                            val text = runCatching {
                                JSONObject(recognizer.result).optString("text", "").trim()
                            }.getOrDefault("")

                            val segStart = utteranceStartMs
                            val segEnd = event.mediaStartMs + event.durationMs
                            utteranceStartMs = -1L

                            if (text.isNotBlank()) {
                                val arabic = translator.translate(
                                    rawSourceText = text,
                                    isFinal = true,
                                    aiTimeoutMs = ArabicTranslator.CINEMA_AI_TIMEOUT_MS
                                )
                                if (arabic.isNotBlank()) {
                                    upsertSubtitleCue(
                                        TimedSubtitleCue(
                                            speechStartMs = segStart,
                                            speechEndMs = segEnd.coerceAtLeast(segStart + 1200L),
                                            arabicText = arabic,
                                            isFinal = true
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } finally {
            runCatching { recognizer.close() }
            runCatching { model.close() }
        }
    }

    fun exportSrtContent(): String {
        val leadMs = settingsStore.currentSettings.cinemaLeadTimeMs
        val sorted = cues.filter { it.arabicText.isNotBlank() }
            .sortedBy { it.speechStartMs }

        if (sorted.isEmpty()) return ""
        val sb = StringBuilder()
        sorted.forEachIndexed { index, cue ->
            val start = (cue.speechStartMs - leadMs).coerceAtLeast(0L)
            val end = (cue.speechEndMs + 300L).coerceAtLeast(start + 900L)
            sb.appendLine(index + 1)
            sb.appendLine("${formatSrtTime(start)} --> ${formatSrtTime(end)}")
            sb.appendLine(cue.arabicText)
            sb.appendLine()
        }
        return sb.toString()
    }

    private fun formatSrtTime(ms: Long): String {
        val hours = ms / 3_600_000L
        val mins = (ms % 3_600_000L) / 60_000L
        val secs = (ms % 60_000L) / 1000L
        val millis = ms % 1000L
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, mins, secs, millis)
    }

    fun release() {
        tickerJob?.cancel()
        transcriptionJob?.cancel()
        audioChannel.close()
        mainPlayer.release()
        scoutPlayer.release()
        translator.close()
        mainScope.cancel()
        ioScope.cancel()
    }

    companion object {
        private const val PREBUFFER_TARGET_LEAD_MS = 4500L
        private const val TARGET_SCOUT_LEAD_MIN_MS = 6500L
        private const val TARGET_SCOUT_LEAD_MAX_MS = 8500L
        private const val TARGET_SCOUT_LEAD_PAUSE_MS = 9200L

        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
    }
}
