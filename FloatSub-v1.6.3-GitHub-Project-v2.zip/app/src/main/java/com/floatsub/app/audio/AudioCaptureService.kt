package com.floatsub.app.audio

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.floatsub.app.data.TranslationSettingsStore
import com.floatsub.app.translation.ArabicTranslator
import com.floatsub.app.ui.BadgeStatus
import com.floatsub.app.ui.FloatingSubtitleWindow
import com.floatsub.app.ui.MainActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.ConnectionPool
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume
import kotlin.math.sqrt

class AudioCaptureService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var settingsStore: TranslationSettingsStore
    private lateinit var okHttpClient: OkHttpClient
    private lateinit var translator: ArabicTranslator
    private lateinit var voskModelManager: VoskModelManager
    private var floatingWindow: FloatingSubtitleWindow? = null

    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var captureJob: Job? = null
    private var translationJob: Job? = null
    private var silenceMonitorJob: Job? = null

    private val isPaused = AtomicBoolean(false)
    private val translationEpoch = AtomicInteger(0)
    private val lastSpeechActivityMs = AtomicLong(System.currentTimeMillis())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        settingsStore = TranslationSettingsStore(this)
        okHttpClient = OkHttpClient.Builder()
            .connectionPool(ConnectionPool(5, 5, TimeUnit.MINUTES))
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .pingInterval(15, TimeUnit.SECONDS)
            .build()

        translator = ArabicTranslator(this, settingsStore, okHttpClient)
        voskModelManager = VoskModelManager(this, okHttpClient)

        floatingWindow = FloatingSubtitleWindow(
            context = this,
            settingsStore = settingsStore,
            onTogglePause = { togglePauseState() },
            onClearNow = { clearCurrentSubtitleImmediately() },
            onOpenSettings = { openMainActivity() },
            onCloseService = { stopCaptureAndSelf() }
        )

        serviceScope.launch(Dispatchers.Main) {
            settingsStore.settingsFlow.collect { settings ->
                floatingWindow?.applyAppearance(settings)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopCaptureAndSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                if (resultCode != Activity.RESULT_OK || resultData == null) {
                    stopCaptureAndSelf()
                    return START_NOT_STICKY
                }

                startForegroundWithProjectionNotification()
                startCaptureSession(resultCode, resultData)
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundWithProjectionNotification() {
        val notification = buildNotification("FloatSub يعمل ويستمع لصوت الفيديو...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startCaptureSession(resultCode: Int, resultData: Intent) {
        captureJob?.cancel()
        silenceMonitorJob?.cancel()
        releaseAudioResources()

        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = projectionManager.getMediaProjection(resultCode, resultData)
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopCaptureAndSelf()
            }
        }, null)
        mediaProjection = projection

        val captureConfig = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val audioFormat = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        val minBufSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(BYTES_PER_100MS * 4)

        val recorder = try {
            AudioRecord.Builder()
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(minBufSize * 2)
                .setAudioPlaybackCaptureConfig(captureConfig)
                .build()
        } catch (e: SecurityException) {
            updateBadgeStatus(BadgeStatus.ERROR)
            stopCaptureAndSelf()
            return
        }

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            updateBadgeStatus(BadgeStatus.ERROR)
            stopCaptureAndSelf()
            return
        }

        recorder.startRecording()
        audioRecord = recorder
        _isRunningFlow.value = true
        isPaused.set(false)
        lastSpeechActivityMs.set(System.currentTimeMillis())

        serviceScope.launch(Dispatchers.Main) {
            floatingWindow?.show()
            floatingWindow?.updateStatus(BadgeStatus.CONNECTING)
        }

        startSilenceMonitor()

        captureJob = serviceScope.launch {
            runSelectedTranscriptionEngine(recorder)
        }
    }

    private suspend fun runSelectedTranscriptionEngine(recorder: AudioRecord) {
        val settings = settingsStore.currentSettings
        when {
            settings.deepgramApiKey.isNotBlank() -> {
                runDeepgramStreamingLoop(recorder)
            }
            settings.groqApiKey.isNotBlank() -> {
                runGroqWhisperLoop(recorder)
            }
            else -> {
                runVoskOfflineLoop(recorder)
            }
        }
    }

    private enum class DeepgramSessionOutcome {
        SWITCH_TO_PCM,
        RECONNECT,
        STOPPED
    }

    private suspend fun runDeepgramStreamingLoop(recorder: AudioRecord) {
        var useOpusInSession = settingsStore.currentSettings.enableOpusCompression

        while (serviceScope.isActive && _isRunningFlow.value) {
            updateBadgeStatus(if (isPaused.get()) BadgeStatus.PAUSED else BadgeStatus.CONNECTING)

            val outcome = try {
                runDeepgramSession(recorder, useOpusInSession)
            } catch (ce: CancellationException) {
                throw ce
            } catch (_: Exception) {
                DeepgramSessionOutcome.RECONNECT
            }

            when (outcome) {
                DeepgramSessionOutcome.SWITCH_TO_PCM -> {
                    useOpusInSession = false
                }
                DeepgramSessionOutcome.RECONNECT -> {
                    if (!_isRunningFlow.value) break
                    updateBadgeStatus(BadgeStatus.CONNECTING)
                    delay(1500L)
                }
                DeepgramSessionOutcome.STOPPED -> break
            }
        }
    }

    private suspend fun runDeepgramSession(
        recorder: AudioRecord,
        useOpus: Boolean
    ): DeepgramSessionOutcome {
        val settings = settingsStore.currentSettings
        val apiKey = settings.deepgramApiKey
        if (apiKey.isBlank()) return DeepgramSessionOutcome.STOPPED

        val langCode = settings.sourceLanguage.code
        val encodingQuery = if (useOpus) {
            "encoding=opus"
        } else {
            "encoding=linear16&sample_rate=$SAMPLE_RATE&channels=1"
        }

        val url = "wss://api.deepgram.com/v1/listen" +
            "?model=nova-2" +
            "&language=$langCode" +
            "&smart_format=true" +
            "&punctuate=true" +
            "&interim_results=true" +
            "&endpointing=100" +
            "&utterance_end_ms=1000" +
            "&vad_events=true" +
            "&$encodingQuery"

        val sessionSignals = Channel<DeepgramSessionOutcome>(Channel.CONFLATED)
        val hasReceivedAnyTranscript = AtomicBoolean(false)
        val socketOpen = AtomicBoolean(false)

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Token $apiKey")
            .build()

        val webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                socketOpen.set(true)
                updateBadgeStatus(if (isPaused.get()) BadgeStatus.PAUSED else BadgeStatus.LISTENING)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleDeepgramMessage(text, hasReceivedAnyTranscript)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                socketOpen.set(false)
                webSocket.close(1000, null)
                sessionSignals.trySend(DeepgramSessionOutcome.RECONNECT)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                socketOpen.set(false)
                updateBadgeStatus(BadgeStatus.ERROR)
                sessionSignals.trySend(DeepgramSessionOutcome.RECONNECT)
            }
        })

        var opusEncoder: OpusOggStreamEncoder? = if (useOpus) {
            runCatching { OpusOggStreamEncoder(SAMPLE_RATE, 1, 24000) }.getOrNull()
        } else {
            null
        }

        if (useOpus && opusEncoder == null) {
            webSocket.cancel()
            return DeepgramSessionOutcome.SWITCH_TO_PCM
        }

        val buffer = ByteArray(BYTES_PER_100MS)
        var accumulatedActiveAudioMs = 0L
        var lastKeepAliveMs = System.currentTimeMillis()

        try {
            while (serviceScope.isActive && _isRunningFlow.value) {
                sessionSignals.tryReceive().getOrNull()?.let { return it }

                val now = System.currentTimeMillis()
                if (socketOpen.get() && now - lastKeepAliveMs >= DEEPGRAM_KEEP_ALIVE_MS) {
                    webSocket.send("""{"type":"KeepAlive"}""")
                    lastKeepAliveMs = now
                }

                val readBytes = recorder.read(buffer, 0, buffer.size)
                if (readBytes <= 0) {
                    delay(15L)
                    continue
                }

                if (isPaused.get() || !socketOpen.get()) {
                    continue
                }

                val rms = computeRms16Bit(buffer, readBytes)
                val chunkDurationMs = (readBytes * 1000L) / (SAMPLE_RATE * 2)

                if (useOpus && !hasReceivedAnyTranscript.get()) {
                    if (rms > OPUS_ACTIVE_RMS_THRESHOLD) {
                        accumulatedActiveAudioMs += chunkDurationMs
                        if (accumulatedActiveAudioMs >= OPUS_SELF_HEAL_TIMEOUT_MS) {
                            return DeepgramSessionOutcome.SWITCH_TO_PCM
                        }
                    }
                }

                if (useOpus && opusEncoder != null) {
                    val oggBytes = opusEncoder.encodePcmChunk(buffer, readBytes)
                    if (oggBytes.isNotEmpty()) {
                        webSocket.send(oggBytes.toByteString(0, oggBytes.size))
                    }
                } else {
                    webSocket.send(buffer.toByteString(0, readBytes))
                }
            }
            return DeepgramSessionOutcome.STOPPED
        } finally {
            opusEncoder?.release()
            opusEncoder = null
            runCatching { webSocket.send("""{"type":"CloseStream"}""") }
            runCatching { webSocket.close(1000, "Session ended") }
        }
    }

    private fun handleDeepgramMessage(
        jsonText: String,
        hasReceivedAnyTranscript: AtomicBoolean
    ) {
        if (isPaused.get()) return
        val root = runCatching { JSONObject(jsonText) }.getOrNull() ?: return
        if (root.optString("type") != "Results") return

        val isFinal = root.optBoolean("is_final", false)
        val transcript = root.optJSONObject("channel")
            ?.optJSONArray("alternatives")
            ?.optJSONObject(0)
            ?.optString("transcript", "")
            ?.trim()
            .orEmpty()

        if (transcript.isBlank()) return
        hasReceivedAnyTranscript.set(true)

        if (translator.isWhisperOrSubtitleHallucination(transcript)) return

        lastSpeechActivityMs.set(System.currentTimeMillis())
        submitTranscriptForTranslation(transcript, isFinal)
    }

    private suspend fun runGroqWhisperLoop(recorder: AudioRecord) {
        updateBadgeStatus(if (isPaused.get()) BadgeStatus.PAUSED else BadgeStatus.LISTENING)

        val readBuf = ByteArray(1920)
        val speechBuffer = ByteArrayOutputStream()

        var isSpeaking = false
        var speechDurationMs = 0L
        var silenceDurationMs = 0L
        var previousTranscriptTail = ""

        while (serviceScope.isActive && _isRunningFlow.value) {
            val read = recorder.read(readBuf, 0, readBuf.size)
            if (read <= 0) {
                delay(15L)
                continue
            }

            if (isPaused.get()) {
                if (speechBuffer.size() > 0) {
                    speechBuffer.reset()
                    isSpeaking = false
                    speechDurationMs = 0L
                    silenceDurationMs = 0L
                }
                continue
            }

            val chunkMs = (read * 1000L) / (SAMPLE_RATE * 2)
            val rms = computeRms16Bit(readBuf, read)

            if (!isSpeaking) {
                if (rms >= WHISPER_RMS_THRESHOLD) {
                    isSpeaking = true
                    speechDurationMs = chunkMs
                    silenceDurationMs = 0L
                    speechBuffer.write(readBuf, 0, read)
                }
            } else {
                speechBuffer.write(readBuf, 0, read)
                speechDurationMs += chunkMs

                if (rms < WHISPER_RMS_THRESHOLD) {
                    silenceDurationMs += chunkMs
                } else {
                    silenceDurationMs = 0L
                }

                val reachedNaturalPause =
                    speechDurationMs >= WHISPER_MIN_SPEECH_MS && silenceDurationMs >= WHISPER_PAUSE_SILENCE_MS
                val reachedMaxChunk = speechDurationMs >= WHISPER_MAX_SPEECH_MS

                if (reachedNaturalPause || reachedMaxChunk) {
                    val pcmSegment = speechBuffer.toByteArray()
                    val speechContinues = reachedMaxChunk && silenceDurationMs < WHISPER_PAUSE_SILENCE_MS

                    speechBuffer.reset()
                    if (speechContinues && pcmSegment.size > WHISPER_OVERLAP_BYTES) {
                        speechBuffer.write(
                            pcmSegment,
                            pcmSegment.size - WHISPER_OVERLAP_BYTES,
                            WHISPER_OVERLAP_BYTES
                        )
                        isSpeaking = true
                        speechDurationMs = 250L
                        silenceDurationMs = 0L
                    } else {
                        isSpeaking = false
                        speechDurationMs = 0L
                        silenceDurationMs = 0L
                    }

                    val rawTranscript = transcribeWithGroqWhisper(pcmSegment)
                    if (!rawTranscript.isNullOrBlank() &&
                        !translator.isWhisperOrSubtitleHallucination(rawTranscript)
                    ) {
                        val cleaned = deduplicateOverlap(previousTranscriptTail, rawTranscript)
                        previousTranscriptTail = rawTranscript
                        if (cleaned.isNotBlank()) {
                            lastSpeechActivityMs.set(System.currentTimeMillis())
                            submitTranscriptForTranslation(cleaned, isFinal = true)
                        }
                    }
                }
            }
        }
    }

    private suspend fun transcribeWithGroqWhisper(pcmBytes: ByteArray): String? {
        val groqKey = settingsStore.currentSettings.groqApiKey
        if (groqKey.isBlank()) return null

        val wavBytes = pcm16MonoToWav(pcmBytes, SAMPLE_RATE)
        val lang = settingsStore.currentSettings.sourceLanguage.code

        val multipartBuilder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "file",
                "chunk.wav",
                wavBytes.toRequestBody("audio/wav".toMediaType())
            )
            .addFormDataPart("model", "whisper-large-v3-turbo")
            .addFormDataPart("response_format", "json")
            .addFormDataPart("temperature", "0")

        if (lang != "multi") {
            multipartBuilder.addFormDataPart("language", lang.substringBefore("-"))
        }

        val request = Request.Builder()
            .url("https://api.groq.com/openai/v1/audio/transcriptions")
            .addHeader("Authorization", "Bearer $groqKey")
            .post(multipartBuilder.build())
            .build()

        return suspendCancellableCoroutine { cont ->
            val call = okHttpClient.newCall(request)
            cont.invokeOnCancellation { call.cancel() }

            call.enqueue(object : okhttp3.Callback {
                override fun onFailure(call: okhttp3.Call, e: IOException) {
                    if (cont.isActive) cont.resume(null)
                }

                override fun onResponse(call: okhttp3.Call, response: Response) {
                    response.use { res ->
                        if (!res.isSuccessful) {
                            if (res.code == 429 || res.code >= 500) {
                                translator.triggerGroqWhisperCooldown()
                            }
                            if (cont.isActive) cont.resume(null)
                            return
                        }
                        val bodyStr = res.body?.string().orEmpty()
                        val text = runCatching {
                            JSONObject(bodyStr).optString("text", "").trim()
                        }.getOrNull()
                        if (cont.isActive) cont.resume(text)
                    }
                }
            })
        }
    }

    internal fun deduplicateOverlap(previousText: String, currentText: String): String {
        if (previousText.isBlank() || currentText.isBlank()) return currentText.trim()
        val prevWords = previousText.trim().split(Regex("\\s+"))
        val currWords = currentText.trim().split(Regex("\\s+"))
        val maxCheck = minOf(6, prevWords.size, currWords.size)

        for (overlapCount in maxCheck downTo 1) {
            val prevSuffix = prevWords.takeLast(overlapCount)
                .joinToString(" ") { it.lowercase().trim('.', ',', '!', '?') }
            val currPrefix = currWords.take(overlapCount)
                .joinToString(" ") { it.lowercase().trim('.', ',', '!', '?') }

            if (prevSuffix.isNotBlank() && prevSuffix == currPrefix) {
                return currWords.drop(overlapCount).joinToString(" ").trim()
            }
        }
        return currentText.trim()
    }

    private suspend fun runVoskOfflineLoop(recorder: AudioRecord) {
        updateBadgeStatus(BadgeStatus.CONNECTING)

        val model = try {
            voskModelManager.ensureModelLoaded { statusMsg ->
                serviceScope.launch(Dispatchers.Main) {
                    floatingWindow?.showSubtitle(statusMsg)
                }
            }
        } catch (_: Exception) {
            updateBadgeStatus(BadgeStatus.ERROR)
            serviceScope.launch(Dispatchers.Main) {
                floatingWindow?.showSubtitle("تعذر تحميل نموذج الصوت الأوفلاين (تحقق من الإنترنت لأول مرة)")
            }
            return
        }

        val recognizer = Recognizer(model, SAMPLE_RATE.toFloat())
        updateBadgeStatus(if (isPaused.get()) BadgeStatus.PAUSED else BadgeStatus.LISTENING)
        clearCurrentSubtitleImmediately()

        val buffer = ByteArray(3200)
        var emittedWordOffset = 0
        var lastPartialText = ""
        var lastPartialChangeMs = System.currentTimeMillis()

        try {
            while (serviceScope.isActive && _isRunningFlow.value) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read <= 0) {
                    delay(15L)
                    continue
                }
                if (isPaused.get()) continue

                val isFinalUtterance = recognizer.acceptWaveForm(buffer, read)
                val now = System.currentTimeMillis()

                if (isFinalUtterance) {
                    val fullText = runCatching {
                        JSONObject(recognizer.result).optString("text", "").trim()
                    }.getOrDefault("")

                    val words = fullText.split(Regex("\\s+")).filter { it.isNotBlank() }
                    if (words.size > emittedWordOffset) {
                        val remainingWords = words.drop(emittedWordOffset)
                        remainingWords.chunked(MAX_WORDS_PER_CUE).forEach { cueWords ->
                            val cue = cueWords.joinToString(" ")
                            lastSpeechActivityMs.set(now)
                            submitTranscriptForTranslation(cue, isFinal = true)
                        }
                    }
                    emittedWordOffset = 0
                    lastPartialText = ""
                } else {
                    val partial = runCatching {
                        JSONObject(recognizer.partialResult).optString("partial", "").trim()
                    }.getOrDefault("")

                    if (partial != lastPartialText) {
                        lastPartialText = partial
                        lastPartialChangeMs = now
                    }

                    val allWords = partial.split(Regex("\\s+")).filter { it.isNotBlank() }
                    val pendingWords = if (allWords.size > emittedWordOffset) {
                        allWords.drop(emittedWordOffset)
                    } else {
                        emptyList()
                    }

                    if (pendingWords.size >= MAX_WORDS_PER_CUE) {
                        val commitCue = pendingWords.take(MAX_WORDS_PER_CUE).joinToString(" ")
                        emittedWordOffset += MAX_WORDS_PER_CUE
                        lastSpeechActivityMs.set(now)
                        submitTranscriptForTranslation(commitCue, isFinal = true)
                    } else if (pendingWords.size >= 3 && (now - lastPartialChangeMs) >= PAUSE_COMMIT_MS) {
                        val commitCue = pendingWords.joinToString(" ")
                        emittedWordOffset += pendingWords.size
                        lastSpeechActivityMs.set(now)
                        submitTranscriptForTranslation(commitCue, isFinal = true)
                    } else if (pendingWords.isNotEmpty()) {
                        lastSpeechActivityMs.set(now)
                        submitTranscriptForTranslation(pendingWords.joinToString(" "), isFinal = false)
                    }
                }
            }
        } finally {
            runCatching { recognizer.close() }
            runCatching { model.close() }
        }
    }

    private fun submitTranscriptForTranslation(sourceText: String, isFinal: Boolean) {
        if (isPaused.get()) return
        val expectedEpoch = translationEpoch.get()

        translationJob?.cancel()
        translationJob = serviceScope.launch {
            val arabicText = translator.translate(sourceText, isFinal = isFinal)
            if (arabicText.isBlank()) return@launch
            if (isPaused.get() || translationEpoch.get() != expectedEpoch) return@launch

            lastSpeechActivityMs.set(System.currentTimeMillis())
            launch(Dispatchers.Main) {
                floatingWindow?.showSubtitle(arabicText)
            }
        }
    }

    private fun startSilenceMonitor() {
        silenceMonitorJob?.cancel()
        silenceMonitorJob = serviceScope.launch {
            while (isActive && _isRunningFlow.value) {
                delay(500L)
                if (!isPaused.get()) {
                    val idleMs = System.currentTimeMillis() - lastSpeechActivityMs.get()
                    if (idleMs > SILENCE_CLEAR_MS) {
                        launch(Dispatchers.Main) {
                            floatingWindow?.clearSubtitle()
                        }
                    }
                }
            }
        }
    }

    private fun togglePauseState() {
        val pausedNow = !isPaused.get()
        isPaused.set(pausedNow)
        translationEpoch.incrementAndGet()
        translationJob?.cancel()

        if (pausedNow) {
            translator.clearSceneHistory()
            updateBadgeStatus(BadgeStatus.PAUSED)
        } else {
            lastSpeechActivityMs.set(System.currentTimeMillis())
            updateBadgeStatus(BadgeStatus.LISTENING)
        }
    }

    private fun clearCurrentSubtitleImmediately() {
        translationEpoch.incrementAndGet()
        translationJob?.cancel()
        serviceScope.launch(Dispatchers.Main) {
            floatingWindow?.clearSubtitle()
        }
    }

    private fun openMainActivity() {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(intent)
    }

    private fun updateBadgeStatus(status: BadgeStatus) {
        serviceScope.launch(Dispatchers.Main) {
            floatingWindow?.updateStatus(status)
        }
    }

    private fun stopCaptureAndSelf() {
        if (!_isRunningFlow.value && mediaProjection == null) {
            stopSelf()
            return
        }
        _isRunningFlow.value = false
        translationEpoch.incrementAndGet()
        captureJob?.cancel()
        translationJob?.cancel()
        silenceMonitorJob?.cancel()
        releaseAudioResources()

        serviceScope.launch(Dispatchers.Main) {
            floatingWindow?.destroy()
            floatingWindow = null
        }

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releaseAudioResources() {
        runCatching {
            audioRecord?.stop()
            audioRecord?.release()
        }
        audioRecord = null

        runCatching { mediaProjection?.stop() }
        mediaProjection = null
    }

    override fun onDestroy() {
        _isRunningFlow.value = false
        releaseAudioResources()
        floatingWindow?.destroy()
        floatingWindow = null
        translator.close()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "FloatSub Live Translation",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "إشعار خدمة التقاط الصوت والترجمة الفورية"
            setShowBadge(false)
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            1,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AudioCaptureService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("FloatSub — الترجمة العائمة نشطة")
            .setContentText(contentText)
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPending)
            .build()
    }

    private fun computeRms16Bit(pcmBytes: ByteArray, length: Int): Double {
        val sampleCount = length / 2
        if (sampleCount <= 0) return 0.0
        var sumSquares = 0.0
        var i = 0
        while (i + 1 < length) {
            val low = pcmBytes[i].toInt() and 0xFF
            val high = pcmBytes[i + 1].toInt()
            val sample = ((high shl 8) or low).toShort().toDouble()
            sumSquares += sample * sample
            i += 2
        }
        return sqrt(sumSquares / sampleCount)
    }

    private fun pcm16MonoToWav(pcmData: ByteArray, sampleRate: Int): ByteArray {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        val byteRate = sampleRate * 2
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(36 + pcmData.size)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16)
        header.putShort(1)
        header.putShort(1)
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort(2)
        header.putShort(16)
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(pcmData.size)

        val out = ByteArray(44 + pcmData.size)
        System.arraycopy(header.array(), 0, out, 0, 44)
        System.arraycopy(pcmData, 0, out, 44, pcmData.size)
        return out
    }

    companion object {
        const val ACTION_START = "com.floatsub.app.action.START_CAPTURE"
        const val ACTION_STOP = "com.floatsub.app.action.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val CHANNEL_ID = "floatsub_live_translation"
        private const val NOTIFICATION_ID = 1001

        private const val SAMPLE_RATE = 16000
        private const val BYTES_PER_100MS = 3200

        private const val OPUS_ACTIVE_RMS_THRESHOLD = 160.0
        private const val OPUS_SELF_HEAL_TIMEOUT_MS = 8000L
        private const val DEEPGRAM_KEEP_ALIVE_MS = 8000L

        private const val SILENCE_CLEAR_MS = 4500L

        private const val WHISPER_RMS_THRESHOLD = 300.0
        private const val WHISPER_MIN_SPEECH_MS = 900L
        private const val WHISPER_PAUSE_SILENCE_MS = 240L
        private const val WHISPER_MAX_SPEECH_MS = 2200L
        private const val WHISPER_OVERLAP_BYTES = 8000

        private const val MAX_WORDS_PER_CUE = 7
        private const val PAUSE_COMMIT_MS = 280L

        private val _isRunningFlow = MutableStateFlow(false)
        val isRunningFlow: StateFlow<Boolean> = _isRunningFlow.asStateFlow()
    }
}
