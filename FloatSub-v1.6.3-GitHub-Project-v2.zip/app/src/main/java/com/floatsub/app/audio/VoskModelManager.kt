package com.floatsub.app.audio

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.vosk.Model
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

class VoskModelManager(
    private val context: Context,
    private val httpClient: OkHttpClient
) {
    private val mutex = Mutex()

    suspend fun ensureModelLoaded(onProgressStatus: (String) -> Unit = {}): Model =
        mutex.withLock {
            withContext(Dispatchers.IO) {
                val baseDir = File(context.filesDir, "vosk_models")
                val targetModelDir = File(baseDir, MODEL_FOLDER_NAME)
                val readyMarker = File(targetModelDir, ".ready")

                if (!readyMarker.exists()) {
                    onProgressStatus("جارٍ تنزيل نموذج الصوت الأوفلاين (Vosk ~40MB)...")
                    downloadAndExtractModel(baseDir, targetModelDir, readyMarker)
                }

                onProgressStatus("جارٍ تهيئة محرك Vosk الأوفلاين...")
                Model(targetModelDir.absolutePath)
            }
        }

    private fun downloadAndExtractModel(
        baseDir: File,
        targetModelDir: File,
        readyMarker: File
    ) {
        if (targetModelDir.exists()) {
            targetModelDir.deleteRecursively()
        }
        baseDir.mkdirs()

        val tempZip = File(baseDir, "$MODEL_FOLDER_NAME.zip")
        val downloadClient = httpClient.newBuilder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(180, TimeUnit.SECONDS)
            .build()

        val request = Request.Builder().url(MODEL_URL).get().build()
        downloadClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("فشل تنزيل نموذج Vosk: HTTP ${response.code}")
            }
            val body = response.body ?: throw IllegalStateException("ملف نموذج Vosk فارغ")
            body.byteStream().use { input ->
                FileOutputStream(tempZip).use { output ->
                    input.copyTo(output, bufferSize = 16 * 1024)
                }
            }
        }

        ZipInputStream(BufferedInputStream(tempZip.inputStream())).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(baseDir, entry.name)
                if (!outFile.canonicalPath.startsWith(baseDir.canonicalPath)) {
                    throw SecurityException("مسار ملف غير آمن داخل حزمة النموذج")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { fos ->
                        zis.copyTo(fos, bufferSize = 8 * 1024)
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        tempZip.delete()
        if (!targetModelDir.exists()) {
            throw IllegalStateException("لم يتم العثور على مجلد نموذج Vosk بعد فك الضغط")
        }
        readyMarker.writeText("ok")
    }

    companion object {
        private const val MODEL_FOLDER_NAME = "vosk-model-small-en-us-0.15"
        private const val MODEL_URL =
            "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    }
}
