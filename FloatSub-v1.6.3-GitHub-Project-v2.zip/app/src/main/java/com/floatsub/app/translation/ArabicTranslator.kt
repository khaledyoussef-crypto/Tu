package com.floatsub.app.translation

import android.content.Context
import android.util.LruCache
import com.floatsub.app.data.AiTranslationMode
import com.floatsub.app.data.TranslationSettingsStore
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume
import kotlin.math.abs

data class ApiKeyCheckResult(
    val provider: String,
    val isValid: Boolean,
    val message: String
)

class ArabicTranslator(
    context: Context,
    private val settingsStore: TranslationSettingsStore,
    private val httpClient: OkHttpClient
) {
    private val appContext = context.applicationContext

    private val translationCache = LruCache<String, String>(850)

    private val sceneMutex = Mutex()
    private val sceneHistory = ArrayDeque<Pair<String, String>>(3)

    private val roundRobinCounter = AtomicInteger(0)

    private val groqCooldownUntilMs = AtomicLong(0L)
    private val geminiCooldownUntilMs = AtomicLong(0L)

    @Volatile
    private var activeGroqModel: String = PREFERRED_GROQ_MODEL

    @Volatile
    private var activeGeminiModel: String = PREFERRED_GEMINI_MODEL

    private val mlKitMutex = Mutex()
    private var mlKitTranslator: Translator? = null
    private val mlKitModelReady = AtomicBoolean(false)

    suspend fun translate(
        rawSourceText: String,
        isFinal: Boolean,
        aiTimeoutMs: Long = AI_TRANSLATION_TIMEOUT_MS
    ): String =
        withContext(Dispatchers.IO) {
            val normalizedSource = rawSourceText.trim().replace(Regex("\\s+"), " ")
            if (normalizedSource.isBlank()) return@withContext ""
            if (isWhisperOrSubtitleHallucination(normalizedSource)) return@withContext ""

            val cacheKey = "${if (isFinal) "F" else "I"}|$normalizedSource"
            synchronized(translationCache) {
                translationCache.get(cacheKey)
            }?.let { cached ->
                return@withContext cached
            }

            val settings = settingsStore.currentSettings
            var rawArabic: String? = null

            if (settings.aiMode == AiTranslationMode.OFFLINE_ONLY) {
                rawArabic = translateOfflineMlKit(normalizedSource)
            } else {
                if (isFinal && settings.aiMode != AiTranslationMode.INSTANT_GOOGLE) {
                    val contextSnapshot = getSceneContextSnapshot()
                    rawArabic = withTimeoutOrNull(aiTimeoutMs) {
                        translateViaSelectedAi(normalizedSource, contextSnapshot)
                    }
                }

                if (rawArabic.isNullOrBlank()) {
                    rawArabic = withTimeoutOrNull(1800L) {
                        translateInstantGoogle(normalizedSource, settings.sourceLanguage.code)
                    }
                }

                if (rawArabic.isNullOrBlank()) {
                    rawArabic = translateOfflineMlKit(normalizedSource)
                }
            }

            val formatted = formatCinemaSubtitle(rawArabic.orEmpty())
            if (formatted.isNotBlank()) {
                synchronized(translationCache) {
                    translationCache.put(cacheKey, formatted)
                }
                if (isFinal) {
                    appendSceneHistory(normalizedSource, formatted.replace("\n", " "))
                }
            }
            formatted
        }

    private suspend fun translateViaSelectedAi(
        sourceText: String,
        historySnapshot: List<Pair<String, String>>
    ): String? {
        val settings = settingsStore.currentSettings
        val now = System.currentTimeMillis()

        val groqReady = settings.groqApiKey.isNotBlank() && now >= groqCooldownUntilMs.get()
        val geminiReady = settings.geminiApiKey.isNotBlank() && now >= geminiCooldownUntilMs.get()

        return when (settings.aiMode) {
            AiTranslationMode.GROQ_ONLY -> {
                if (groqReady) callGroqChatTranslation(settings.groqApiKey, sourceText, historySnapshot)
                else null
            }
            AiTranslationMode.GEMINI_ONLY -> {
                if (geminiReady) callGeminiTranslation(settings.geminiApiKey, sourceText, historySnapshot)
                else null
            }
            AiTranslationMode.AUTO_HYBRID -> {
                when {
                    groqReady && geminiReady -> {
                        val useGroqFirst = (roundRobinCounter.getAndIncrement() and 1) == 0
                        if (useGroqFirst) {
                            callGroqChatTranslation(settings.groqApiKey, sourceText, historySnapshot)
                                ?: callGeminiTranslation(settings.geminiApiKey, sourceText, historySnapshot)
                        } else {
                            callGeminiTranslation(settings.geminiApiKey, sourceText, historySnapshot)
                                ?: callGroqChatTranslation(settings.groqApiKey, sourceText, historySnapshot)
                        }
                    }
                    groqReady -> callGroqChatTranslation(settings.groqApiKey, sourceText, historySnapshot)
                    geminiReady -> callGeminiTranslation(settings.geminiApiKey, sourceText, historySnapshot)
                    else -> null
                }
            }
            else -> null
        }
    }

    private suspend fun callGroqChatTranslation(
        apiKey: String,
        sourceText: String,
        historySnapshot: List<Pair<String, String>>,
        allowModelDiscoveryRetry: Boolean = true
    ): String? {
        val userPrompt = buildUserPromptWithScene(sourceText, historySnapshot)
        val payload = JSONObject().apply {
            put("model", activeGroqModel)
            put("temperature", 0.15)
            put("max_tokens", 90)
            put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", CINEMA_SYSTEM_PROMPT))
                    .put(JSONObject().put("role", "user").put("content", userPrompt))
            )
        }

        val request = Request.Builder()
            .url("https://api.groq.com/openai/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        val (code, body) = executeCancellableHttp(request) ?: run {
            setGroqCooldown(COOLDOWN_NORMAL_MS)
            return null
        }

        if (code in 200..299 && !body.isNullOrBlank()) {
            val content = runCatching {
                JSONObject(body)
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .optString("content", "")
                    .trim()
            }.getOrNull()

            if (!content.isNullOrBlank() && !containsModelMetaCommentary(content)) {
                return content
            }
            setGroqCooldown(COOLDOWN_NORMAL_MS)
            return null
        }

        if ((code == 400 || code == 404) && allowModelDiscoveryRetry) {
            val discovered = discoverAvailableGroqModel(apiKey)
            if (!discovered.isNullOrBlank() && discovered != activeGroqModel) {
                activeGroqModel = discovered
                return callGroqChatTranslation(apiKey, sourceText, historySnapshot, false)
            }
        }

        val cooldown = if (code == 429 || code >= 500) COOLDOWN_EXTENDED_MS else COOLDOWN_NORMAL_MS
        setGroqCooldown(cooldown)
        return null
    }

    private suspend fun discoverAvailableGroqModel(apiKey: String): String? {
        val request = Request.Builder()
            .url("https://api.groq.com/openai/v1/models")
            .addHeader("Authorization", "Bearer $apiKey")
            .get()
            .build()

        val (code, body) = executeCancellableHttp(request) ?: return null
        if (code !in 200..299 || body.isNullOrBlank()) return null

        return runCatching {
            val data = JSONObject(body).optJSONArray("data") ?: return null
            val ids = ArrayList<String>(data.length())
            for (i in 0 until data.length()) {
                val id = data.getJSONObject(i).optString("id", "")
                if (id.isNotBlank() && !id.contains("whisper", ignoreCase = true) &&
                    !id.contains("guard", ignoreCase = true) && !id.contains("tts", ignoreCase = true)
                ) {
                    ids.add(id)
                }
            }
            ids.firstOrNull { it == PREFERRED_GROQ_MODEL }
                ?: ids.firstOrNull { it.contains("instant", ignoreCase = true) }
                ?: ids.firstOrNull { it.contains("llama", ignoreCase = true) }
                ?: ids.firstOrNull()
        }.getOrNull()
    }

    private suspend fun callGeminiTranslation(
        apiKey: String,
        sourceText: String,
        historySnapshot: List<Pair<String, String>>,
        allowModelDiscoveryRetry: Boolean = true
    ): String? {
        val modelName = activeGeminiModel.removePrefix("models/")
        val url =
            "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"

        val userPrompt = buildUserPromptWithScene(sourceText, historySnapshot)
        val payload = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", CINEMA_SYSTEM_PROMPT))
                )
            )
            put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))
                )
            )
            put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.15)
                    .put("maxOutputTokens", 90)
            )
        }

        val request = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        val (code, body) = executeCancellableHttp(request) ?: run {
            setGeminiCooldown(COOLDOWN_NORMAL_MS)
            return null
        }

        if (code in 200..299 && !body.isNullOrBlank()) {
            val content = runCatching {
                JSONObject(body)
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .optString("text", "")
                    .trim()
            }.getOrNull()

            if (!content.isNullOrBlank() && !containsModelMetaCommentary(content)) {
                return content
            }
            setGeminiCooldown(COOLDOWN_NORMAL_MS)
            return null
        }

        if ((code == 400 || code == 404) && allowModelDiscoveryRetry) {
            val discovered = discoverAvailableGeminiModel(apiKey)
            if (!discovered.isNullOrBlank() && discovered != activeGeminiModel) {
                activeGeminiModel = discovered
                return callGeminiTranslation(apiKey, sourceText, historySnapshot, false)
            }
        }

        val cooldown = if (code == 429 || code >= 500) COOLDOWN_EXTENDED_MS else COOLDOWN_NORMAL_MS
        setGeminiCooldown(cooldown)
        return null
    }

    private suspend fun discoverAvailableGeminiModel(apiKey: String): String? {
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models?key=$apiKey")
            .get()
            .build()

        val (code, body) = executeCancellableHttp(request) ?: return null
        if (code !in 200..299 || body.isNullOrBlank()) return null

        return runCatching {
            val models = JSONObject(body).optJSONArray("models") ?: return null
            val supported = ArrayList<String>()
            for (i in 0 until models.length()) {
                val obj = models.getJSONObject(i)
                val name = obj.optString("name", "").removePrefix("models/")
                val methods = obj.optJSONArray("supportedGenerationMethods")
                var supportsGenerate = false
                if (methods != null) {
                    for (j in 0 until methods.length()) {
                        if (methods.optString(j) == "generateContent") {
                            supportsGenerate = true
                            break
                        }
                    }
                }
                if (supportsGenerate && name.startsWith("gemini") && !name.contains("tts")) {
                    supported.add(name)
                }
            }
            supported.firstOrNull { it == PREFERRED_GEMINI_MODEL }
                ?: supported.firstOrNull { it.contains("2.0-flash") }
                ?: supported.firstOrNull { it.contains("flash") }
                ?: supported.firstOrNull()
        }.getOrNull()
    }

    suspend fun translateInstantGoogle(sourceText: String, sourceLangCode: String): String? {
        val sl = if (sourceLangCode == "multi" || sourceLangCode.isBlank()) {
            "auto"
        } else {
            sourceLangCode.substringBefore("-")
        }

        val url = "https://translate.googleapis.com/translate_a/single".toHttpUrl()
            .newBuilder()
            .addQueryParameter("client", "gtx")
            .addQueryParameter("sl", sl)
            .addQueryParameter("tl", "ar")
            .addQueryParameter("dt", "t")
            .addQueryParameter("q", sourceText)
            .build()

        val request = Request.Builder()
            .url(url)
            .addHeader("User-Agent", "Mozilla/5.0")
            .get()
            .build()

        val (code, body) = executeCancellableHttp(request) ?: return null
        if (code !in 200..299 || body.isNullOrBlank()) return null

        return runCatching {
            val outer = JSONArray(body)
            val sentences = outer.optJSONArray(0) ?: return null
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val seg = sentences.optJSONArray(i)?.optString(0, "").orEmpty()
                sb.append(seg)
            }
            sb.toString().trim().takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    private suspend fun translateOfflineMlKit(sourceText: String): String? {
        val client = ensureMlKitTranslatorReady() ?: return null
        return runCatching {
            client.translate(sourceText).await().trim()
        }.getOrNull()
    }

    private suspend fun ensureMlKitTranslatorReady(): Translator? = mlKitMutex.withLock {
        if (mlKitTranslator == null) {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.ARABIC)
                .build()
            mlKitTranslator = Translation.getClient(options)
        }
        val translator = mlKitTranslator ?: return@withLock null
        if (!mlKitModelReady.get()) {
            val downloaded = runCatching {
                val conditions = DownloadConditions.Builder().build()
                translator.downloadModelIfNeeded(conditions).await()
                true
            }.getOrDefault(false)
            mlKitModelReady.set(downloaded)
        }
        if (mlKitModelReady.get()) translator else null
    }

    fun resetCooldowns() {
        groqCooldownUntilMs.set(0L)
        geminiCooldownUntilMs.set(0L)
    }

    fun triggerGroqWhisperCooldown() {
        setGroqCooldown(COOLDOWN_EXTENDED_MS)
    }

    private fun setGroqCooldown(durationMs: Long) {
        groqCooldownUntilMs.set(System.currentTimeMillis() + durationMs)
    }

    private fun setGeminiCooldown(durationMs: Long) {
        geminiCooldownUntilMs.set(System.currentTimeMillis() + durationMs)
    }

    suspend fun verifyAllConfiguredKeys(): List<ApiKeyCheckResult> = withContext(Dispatchers.IO) {
        resetCooldowns()
        val settings = settingsStore.currentSettings
        val results = ArrayList<ApiKeyCheckResult>()

        if (settings.deepgramApiKey.isNotBlank()) {
            val req = Request.Builder()
                .url("https://api.deepgram.com/v1/projects")
                .addHeader("Authorization", "Token ${settings.deepgramApiKey}")
                .get()
                .build()
            val (code, _) = executeCancellableHttp(req) ?: (-1 to null)
            results.add(
                ApiKeyCheckResult(
                    provider = "Deepgram",
                    isValid = code in 200..299,
                    message = if (code in 200..299) "مفتاح صالح ومتصل بنجاح" else "فشل التحقق (HTTP $code)"
                )
            )
        }

        if (settings.groqApiKey.isNotBlank()) {
            val discovered = discoverAvailableGroqModel(settings.groqApiKey)
            if (!discovered.isNullOrBlank()) activeGroqModel = discovered
            results.add(
                ApiKeyCheckResult(
                    provider = "Groq AI",
                    isValid = !discovered.isNullOrBlank(),
                    message = if (!discovered.isNullOrBlank()) "مفتاح صالح ($activeGroqModel)" else "مفتاح غير صالح أو تعذر الاتصال"
                )
            )
        }

        if (settings.geminiApiKey.isNotBlank()) {
            val discovered = discoverAvailableGeminiModel(settings.geminiApiKey)
            if (!discovered.isNullOrBlank()) activeGeminiModel = discovered
            results.add(
                ApiKeyCheckResult(
                    provider = "Gemini AI",
                    isValid = !discovered.isNullOrBlank(),
                    message = if (!discovered.isNullOrBlank()) "مفتاح صالح ($activeGeminiModel)" else "مفتاح غير صالح أو تعذر الاتصال"
                )
            )
        }

        results
    }

    fun formatCinemaSubtitle(rawText: String): String {
        if (rawText.isBlank()) return ""

        var cleaned = rawText
            .replace(Regex("```[a-zA-Z]*"), "")
            .replace("```", "")
            .replace("*", "")
            .replace("\"", "")
            .replace("“", "")
            .replace("”", "")
            .replace("«", "")
            .replace("»", "")
            .trim()

        cleaned = cleaned.replace(
            Regex("^(الترجمة العربية|الترجمة|ترجمة|Translation|Arabic)\\s*[:：-]\\s*", RegexOption.IGNORE_CASE),
            ""
        ).trim()

        val validLines = cleaned.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !containsModelMetaCommentary(it) }

        if (validLines.isEmpty()) return ""
        val singleLine = validLines.joinToString(" ").replace(Regex("\\s+"), " ").trim()

        if (containsModelMetaCommentary(singleLine)) return ""

        if (singleLine.length <= MAX_CHARS_PER_SINGLE_LINE) {
            return singleLine
        }

        val mid = singleLine.length / 2
        var bestSpaceIndex = -1
        var smallestDistance = Int.MAX_VALUE

        for (i in singleLine.indices) {
            if (singleLine[i] == ' ') {
                val dist = abs(i - mid)
                if (dist < smallestDistance) {
                    smallestDistance = dist
                    bestSpaceIndex = i
                }
            }
        }

        return if (bestSpaceIndex in 1 until singleLine.lastIndex) {
            val line1 = singleLine.substring(0, bestSpaceIndex).trim()
            val line2 = singleLine.substring(bestSpaceIndex + 1).trim()
            "$line1\n$line2"
        } else {
            singleLine
        }
    }

    private fun containsModelMetaCommentary(text: String): Boolean {
        val lower = text.lowercase()
        return META_COMMENTARY_MARKERS.any { marker -> lower.contains(marker) }
    }

    fun isWhisperOrSubtitleHallucination(transcript: String): Boolean {
        val normalized = transcript.trim().lowercase()
        if (normalized.isEmpty()) return true

        val stripped = normalized.trim('.', ',', '!', '?', '…', '-', ' ')
        if (stripped in HALLUCINATION_EXACT_PHRASES) return true
        if (HALLUCINATION_SUBSTRINGS.any { normalized.contains(it) }) return true

        val words = stripped.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size >= 5 && words.distinct().size == 1) return true

        return false
    }

    private suspend fun getSceneContextSnapshot(): List<Pair<String, String>> =
        sceneMutex.withLock { sceneHistory.toList() }

    private suspend fun appendSceneHistory(source: String, arabic: String) {
        sceneMutex.withLock {
            if (sceneHistory.peekLast()?.first == source) return@withLock
            if (sceneHistory.size >= 3) {
                sceneHistory.removeFirst()
            }
            sceneHistory.addLast(source to arabic)
        }
    }

    fun clearSceneHistory() {
        synchronized(sceneHistory) {
            sceneHistory.clear()
        }
    }

    private fun buildUserPromptWithScene(
        currentLine: String,
        history: List<Pair<String, String>>
    ): String {
        if (history.isEmpty()) return currentLine
        val sb = StringBuilder()
        sb.appendLine("سياق الجمل السابقة (للاتساق فقط ولا تعد ترجمتها):")
        history.forEachIndexed { idx, (src, ar) ->
            sb.appendLine("${idx + 1}) $src => $ar")
        }
        sb.appendLine("الجملة المطلوب ترجمتها الآن فقط:")
        sb.append(currentLine)
        return sb.toString()
    }

    private suspend fun executeCancellableHttp(request: Request): Pair<Int, String?>? =
        suspendCancellableCoroutine { cont ->
            val call = httpClient.newCall(request)
            cont.invokeOnCancellation { call.cancel() }

            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (cont.isActive) cont.resume(null)
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use { res ->
                        val bodyStr = runCatching { res.body?.string() }.getOrNull()
                        if (cont.isActive) cont.resume(res.code to bodyStr)
                    }
                }
            })
        }

    fun close() {
        runCatching { mlKitTranslator?.close() }
        mlKitTranslator = null
    }

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        private const val PREFERRED_GROQ_MODEL = "llama-3.1-8b-instant"
        private const val PREFERRED_GEMINI_MODEL = "gemini-2.0-flash"

        const val AI_TRANSLATION_TIMEOUT_MS = 500L
        const val CINEMA_AI_TIMEOUT_MS = 2200L
        private const val COOLDOWN_NORMAL_MS = 20_000L
        private const val COOLDOWN_EXTENDED_MS = 60_000L
        private const val MAX_CHARS_PER_SINGLE_LINE = 42

        private const val CINEMA_SYSTEM_PROMPT = """
أنت مترجم أفلام ووثائقيات محترف إلى العربية الفصحى السينمائية السلسة.
القواعد الصارمة:
1) أخرج النص المترجم بالعربية فقط بدون أي شرح أو مقدمات أو علامات اقتباس.
2) اجعل الصياغة موجزة وطبيعية ومناسبة لشاشة الترجمة السينمائية.
3) استعن بسياق الجمل السابقة لفهم الضمائر وتصحيح أخطاء التفريغ الصوتي الواضحة، لكن ترجم الجملة الحالية فقط.
"""

        private val META_COMMENTARY_MARKERS = listOf(
            "في هذا الحوار",
            "قمت بترجم",
            "الترجمة الحرفية",
            "يمكن ترجمة",
            "تعني هذه الجملة",
            "ملاحظة:",
            "here is the translation"
        )

        private val HALLUCINATION_EXACT_PHRASES = setOf(
            "thank you",
            "thanks for watching",
            "thank you for watching",
            "you",
            "bye",
            "amara.org"
        )

        private val HALLUCINATION_SUBSTRINGS = listOf(
            "subtitles by",
            "captioned by",
            "amara.org",
            "subscribe to",
            "transcribed by"
        )
    }
}
