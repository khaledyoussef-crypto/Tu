package com.floatsub.app.player

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.floatsub.app.audio.AudioCaptureService
import com.floatsub.app.data.FloatSubSettings
import com.floatsub.app.data.SubtitleBgStyle
import com.floatsub.app.data.SubtitleLeadPreset
import com.floatsub.app.data.TranslationSettingsStore
import kotlinx.coroutines.delay
import java.util.Locale

@OptIn(UnstableApi::class)
class CinemaPlayerActivity : ComponentActivity() {

    private lateinit var settingsStore: TranslationSettingsStore
    private lateinit var engine: LookAheadCinemaEngine

    private val saveSrtLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/x-subrip")
    ) { uri ->
        if (uri != null) {
            val content = engine.exportSrtContent()
            if (content.isBlank()) {
                Toast.makeText(this, "لا توجد جمل مترجمة لتصديرها بعد", Toast.LENGTH_SHORT).show()
            } else {
                runCatching {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(content.toByteArray(Charsets.UTF_8))
                    }
                    Toast.makeText(this, "تم حفظ ملف الترجمة SRT بنجاح", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()

        // إيقاف النافذة العائمة إن كانت تعمل لعدم ازدواجية الترجمة
        if (AudioCaptureService.isRunningFlow.value) {
            startService(Intent(this, AudioCaptureService::class.java).apply {
                action = AudioCaptureService.ACTION_STOP
            })
        }

        settingsStore = TranslationSettingsStore(this)
        engine = LookAheadCinemaEngine(this, settingsStore)

        resolveIncomingMedia(intent)?.let { (uri, title) ->
            engine.loadMedia(uri, title)
        } ?: run {
            Toast.makeText(this, "لم يتم العثور على رابط أو ملف فيديو صالح", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val playerState by engine.uiState.collectAsState()
                val settings by settingsStore.settingsFlow.collectAsState()
                val config = LocalConfiguration.current

                CinemaPlayerScreen(
                    engine = engine,
                    state = playerState,
                    settings = settings,
                    onBack = { finish() },
                    onToggleOrientation = {
                        requestedOrientation =
                            if (config.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                            } else {
                                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            }
                    },
                    onExportSrt = {
                        saveSrtLauncher.launch("FloatSub-Subtitles.srt")
                    },
                    onUpdateCinemaSync = { leadMs, preBuffer ->
                        settingsStore.updateCinemaSettings(leadMs, preBuffer)
                    }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        resolveIncomingMedia(intent)?.let { (uri, title) ->
            engine.loadMedia(uri, title)
        }
    }

    override fun onPause() {
        super.onPause()
        if (isFinishing) {
            engine.release()
        }
    }

    override fun onDestroy() {
        engine.release()
        super.onDestroy()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun resolveIncomingMedia(intent: Intent?): Pair<Uri, String>? {
        if (intent == null) return null
        val customTitle = intent.getStringExtra(EXTRA_MEDIA_TITLE).orEmpty()

        when (intent.action) {
            ACTION_LAUNCH_PLAYER, Intent.ACTION_VIEW -> {
                val dataUri = intent.data
                if (dataUri != null) return dataUri to customTitle
            }
            Intent.ACTION_SEND -> {
                if (intent.type?.startsWith("video/") == true) {
                    val streamUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(Intent.EXTRA_STREAM)
                    }
                    if (streamUri != null) return streamUri to customTitle
                } else if (intent.type == "text/plain") {
                    val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
                    val urlMatch = Regex("https?://\\S+").find(sharedText)?.value
                    if (!urlMatch.isNullOrBlank()) {
                        return Uri.parse(urlMatch) to customTitle
                    }
                }
            }
        }
        return null
    }

    companion object {
        const val ACTION_LAUNCH_PLAYER = "com.floatsub.app.action.LAUNCH_CINEMA_PLAYER"
        const val EXTRA_MEDIA_TITLE = "extra_media_title"

        fun createIntent(context: Context, mediaUri: Uri, title: String = ""): Intent {
            return Intent(context, CinemaPlayerActivity::class.java).apply {
                action = ACTION_LAUNCH_PLAYER
                data = mediaUri
                putExtra(EXTRA_MEDIA_TITLE, title)
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun CinemaPlayerScreen(
    engine: LookAheadCinemaEngine,
    state: CinemaPlayerUiState,
    settings: FloatSubSettings,
    onBack: () -> Unit,
    onToggleOrientation: () -> Unit,
    onExportSrt: () -> Unit,
    onUpdateCinemaSync: (Long, Boolean) -> Unit
) {
    var controlsVisible by remember { mutableStateOf(true) }
    var isScreenLocked by remember { mutableStateOf(false) }
    var resizeMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }

    var isUserScrubbing by remember { mutableStateOf(false) }
    var scrubPositionMs by remember { mutableFloatStateOf(0f) }

    var seekFeedbackText by remember { mutableStateOf<String?>(null) }

    var showQualityDialog by remember { mutableStateOf(false) }
    var showSyncDialog by remember { mutableStateOf(false) }
    var showSpeedDialog by remember { mutableStateOf(false) }

    // إخفاء تلقائي لأزرار التحكم بعد 4 ثوانٍ أثناء التشغيل
    LaunchedEffect(controlsVisible, state.isPlaying, isUserScrubbing) {
        if (controlsVisible && state.isPlaying && !isUserScrubbing && !isScreenLocked) {
            delay(4000L)
            controlsVisible = false
        }
    }

    LaunchedEffect(seekFeedbackText) {
        if (seekFeedbackText != null) {
            delay(650L)
            seekFeedbackText = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(isScreenLocked) {
                detectTapGestures(
                    onTap = {
                        controlsVisible = !controlsVisible
                    },
                    onDoubleTap = { offset ->
                        if (isScreenLocked) return@detectTapGestures
                        val width = size.width
                        when {
                            offset.x < width * 0.38f -> {
                                engine.seekBy(-10_000L)
                                seekFeedbackText = "⏪ -10 ثوانٍ"
                            }
                            offset.x > width * 0.62f -> {
                                engine.seekBy(10_000L)
                                seekFeedbackText = "10 ثوانٍ + ⏩"
                            }
                            else -> {
                                engine.togglePlayPause()
                            }
                        }
                    }
                )
            }
    ) {
        // 1) سطح الفيديو ExoPlayer
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    keepScreenOn = true
                    player = engine.mainPlayer
                    this.resizeMode = resizeMode
                }
            },
            update = { view ->
                view.resizeMode = resizeMode
            },
            modifier = Modifier.fillMaxSize()
        )

        // 2) شريط الترجمة السينمائية المتقدمة قبل النطق
        if (state.activeSubtitle.isNotBlank()) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(
                            start = 24.dp,
                            end = 24.dp,
                            bottom = if (controlsVisible && !isScreenLocked) 128.dp else 36.dp
                        )
                ) {
                    val subBg = if (settings.bgStyle == SubtitleBgStyle.NONE) {
                        Color.Transparent
                    } else {
                        Color(settings.bgStyle.colorArgb)
                    }

                    Text(
                        text = state.activeSubtitle,
                        fontSize = settings.fontSize.sp.sp,
                        color = Color(settings.textColor.colorArgb),
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        lineHeight = (settings.fontSize.sp + 6).sp,
                        style = TextStyle(
                            shadow = Shadow(
                                color = Color.Black,
                                blurRadius = if (settings.bgStyle == SubtitleBgStyle.NONE) 10f else 4f
                            )
                        ),
                        modifier = Modifier
                            .background(subBg, RoundedCornerShape(10.dp))
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
        }

        // 3) مؤشر التقديم أو التأخير السريع باللمس المزدوج
        AnimatedVisibility(
            visible = seekFeedbackText != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Text(
                text = seekFeedbackText.orEmpty(),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier
                    .background(Color(0xBB000000), RoundedCornerShape(24.dp))
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            )
        }

        // 4) بطاقة التجهيز المسبق للترجمة (تضمن ظهور الجملة قبل النطق بثانية)
        if (state.isPreTranslating) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xE6111827)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(20.dp)
                    ) {
                        CircularProgressIndicator(
                            color = Color(0xFFF5C518),
                            modifier = Modifier.size(32.dp),
                            strokeWidth = 3.dp
                        )
                        Text(
                            text = "جارٍ استباق الصوت وتجهيز الترجمة قبل النطق...",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        LinearProgressIndicator(
                            progress = { state.preTranslateProgress },
                            color = Color(0xFFF5C518),
                            modifier = Modifier.width(220.dp)
                        )
                        TextButton(onClick = { engine.skipPreBufferNow() }) {
                            Text("تشغيل فوري بدون انتظار", color = Color(0xFF38BDF8))
                        }
                    }
                }
            }
        } else if (state.isBuffering) {
            CircularProgressIndicator(
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // رسالة الخطأ إن وجدت
        state.errorMessage?.let { err ->
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Text(
                    text = err,
                    color = Color(0xFFFCA5A5),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 72.dp, start = 16.dp, end = 16.dp)
                        .background(Color(0xCC7F1D1D), RoundedCornerShape(10.dp))
                        .padding(12.dp)
                )
            }
        }

        // 5) وضع قفل الشاشة
        if (isScreenLocked && controlsVisible) {
            IconButton(
                onClick = { isScreenLocked = false },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(24.dp)
                    .background(Color(0xAA000000), CircleShape)
            ) {
                Icon(Icons.Default.Lock, contentDescription = "فتح القفل", tint = Color(0xFFF5C518))
            }
        }

        // 6) واجهة التحكم الكاملة (HUD)
        AnimatedVisibility(
            visible = controlsVisible && !isScreenLocked,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xCC000000),
                                Color(0x33000000),
                                Color(0x33000000),
                                Color(0xDD000000)
                            )
                        )
                    )
            ) {
                // الشريط العلوي
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            IconButton(onClick = onBack) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = Color.White)
                            }
                            Column(modifier = Modifier.padding(start = 4.dp)) {
                                Text(
                                    text = state.mediaTitle,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 15.sp
                                )
                                val leadSec = String.format(Locale.US, "%.1fs", state.lookAheadLeadMs / 1000.0)
                                Text(
                                    text = "الجودة: ${state.activeResolutionLabel} • استباق الصوت: +$leadSec • جمل مترجمة: ${state.translatedCueCount}",
                                    color = Color(0xFF86EFAC),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onExportSrt) {
                                Icon(Icons.Default.Download, contentDescription = "حفظ SRT", tint = Color.White)
                            }
                            IconButton(onClick = onToggleOrientation) {
                                Icon(Icons.Default.ScreenRotation, contentDescription = "تدوير الشاشة", tint = Color.White)
                            }
                            IconButton(onClick = { isScreenLocked = true }) {
                                Icon(Icons.Default.LockOpen, contentDescription = "قفل اللمس", tint = Color.White)
                            }
                        }
                    }
                }

                // أزرار المنتصف (تأخير 10 ثوانٍ / تشغيل وإيقاف / تقديم 10 ثوانٍ) باتجاه LTR القياسي للمشغلات
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(36.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.align(Alignment.Center)
                    ) {
                        IconButton(
                            onClick = { engine.seekBy(-10_000L) },
                            modifier = Modifier
                                .size(54.dp)
                                .background(Color(0x66000000), CircleShape)
                        ) {
                            Icon(
                                Icons.Default.Replay10,
                                contentDescription = "-10s",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        IconButton(
                            onClick = { engine.togglePlayPause() },
                            modifier = Modifier
                                .size(68.dp)
                                .background(Color(0xCCF5C518), CircleShape)
                        ) {
                            Icon(
                                imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = Color.Black,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        IconButton(
                            onClick = { engine.seekBy(10_000L) },
                            modifier = Modifier
                                .size(54.dp)
                                .background(Color(0x66000000), CircleShape)
                        ) {
                            Icon(
                                Icons.Default.Forward10,
                                contentDescription = "+10s",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }

                // الشريط السفلي: شريط التقديم والتأخير + أزرار الجودة والتوقيت والسرعة والأبعاد
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        val safeDuration = state.durationMs.coerceAtLeast(1L).toFloat()
                        val sliderValue = if (isUserScrubbing) {
                            scrubPositionMs
                        } else {
                            state.currentPositionMs.toFloat().coerceIn(0f, safeDuration)
                        }

                        Slider(
                            value = sliderValue,
                            onValueChange = { newVal ->
                                isUserScrubbing = true
                                scrubPositionMs = newVal
                            },
                            onValueChangeFinished = {
                                engine.seekTo(scrubPositionMs.toLong())
                                isUserScrubbing = false
                            },
                            valueRange = 0f..safeDuration,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFF5C518),
                                activeTrackColor = Color(0xFFF5C518),
                                inactiveTrackColor = Color(0x55FFFFFF)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp)
                        ) {
                            val shownPos = if (isUserScrubbing) scrubPositionMs.toLong() else state.currentPositionMs
                            Text(
                                text = formatPlayerClock(shownPos),
                                color = Color.White,
                                fontSize = 12.sp
                            )
                            Text(
                                text = formatPlayerClock(state.durationMs),
                                color = Color(0xFFD1D5DB),
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            AssistChip(
                                onClick = { showQualityDialog = true },
                                label = { Text("الجودة (${state.activeResolutionLabel})", fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(Icons.Default.HighQuality, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                colors = AssistChipDefaults.assistChipColors(labelColor = Color.White, leadingIconContentColor = Color(0xFFF5C518))
                            )

                            val leadLabel = String.format(Locale.US, "-%.1fs", settings.cinemaLeadTimeMs / 1000.0)
                            AssistChip(
                                onClick = { showSyncDialog = true },
                                label = { Text("قبل النطق ($leadLabel)", fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(Icons.Default.Subtitles, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                colors = AssistChipDefaults.assistChipColors(labelColor = Color.White, leadingIconContentColor = Color(0xFF38BDF8))
                            )

                            AssistChip(
                                onClick = { showSpeedDialog = true },
                                label = { Text("${state.playbackSpeed}x", fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                colors = AssistChipDefaults.assistChipColors(labelColor = Color.White, leadingIconContentColor = Color.White)
                            )

                            AssistChip(
                                onClick = {
                                    resizeMode = when (resizeMode) {
                                        AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                        AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    }
                                },
                                label = {
                                    val modeText = when (resizeMode) {
                                        AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "ملء"
                                        AspectRatioFrameLayout.RESIZE_MODE_FILL -> "تمديد"
                                        else -> "ملائمة"
                                    }
                                    Text(modeText, fontSize = 12.sp)
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.AspectRatio, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                colors = AssistChipDefaults.assistChipColors(labelColor = Color.White, leadingIconContentColor = Color.White)
                            )
                        }
                    }
                }
            }
        }
    }

    // نافذة اختيار جودة الفيديو
    if (showQualityDialog) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AlertDialog(
                onDismissRequest = { showQualityDialog = false },
                title = { Text("التحكم في جودة الفيديو") },
                text = {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        state.availableQualities.forEach { opt ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        engine.selectQuality(opt)
                                        showQualityDialog = false
                                    }
                                    .padding(vertical = 8.dp)
                            ) {
                                RadioButton(
                                    selected = state.selectedQualityId == opt.id,
                                    onClick = {
                                        engine.selectQuality(opt)
                                        showQualityDialog = false
                                    }
                                )
                                Text(text = opt.labelAr, modifier = Modifier.weight(1f))
                                if (state.selectedQualityId == opt.id) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF22C55E))
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showQualityDialog = false }) {
                        Text("إغلاق")
                    }
                }
            )
        }
    }

    // نافذة ضبط توقيت ظهور الترجمة قبل النطق
    if (showSyncDialog) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AlertDialog(
                onDismissRequest = { showSyncDialog = false },
                title = { Text("توقيت ظهور الترجمة السينمائية") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "اختر بكم ثانية تسبق الترجمة صوت المتحدث:",
                            style = MaterialTheme.typography.bodySmall
                        )
                        SubtitleLeadPreset.entries.forEach { preset ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onUpdateCinemaSync(preset.ms, settings.cinemaPreBufferOnSeek)
                                    }
                            ) {
                                RadioButton(
                                    selected = SubtitleLeadPreset.fromMs(settings.cinemaLeadTimeMs) == preset,
                                    onClick = {
                                        onUpdateCinemaSync(preset.ms, settings.cinemaPreBufferOnSeek)
                                    }
                                )
                                Text(preset.labelAr)
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        ) {
                            Text(
                                text = "تجهيز مسبق (2.5 ثانية) عند التقديم لمشهد جديد",
                                modifier = Modifier.weight(1f),
                                fontSize = 13.sp
                            )
                            Switch(
                                checked = settings.cinemaPreBufferOnSeek,
                                onCheckedChange = { enabled ->
                                    onUpdateCinemaSync(settings.cinemaLeadTimeMs, enabled)
                                }
                            )
                        }
                    }
                },
                confirmButton = {
                    OutlinedButton(onClick = { showSyncDialog = false }) {
                        Text("تم")
                    }
                }
            )
        }
    }

    // نافذة سرعة التشغيل
    if (showSpeedDialog) {
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AlertDialog(
                onDismissRequest = { showSpeedDialog = false },
                title = { Text("سرعة تشغيل الفيديو") },
                text = {
                    Column {
                        speeds.forEach { spd ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        engine.setPlaybackSpeed(spd)
                                        showSpeedDialog = false
                                    }
                                    .padding(vertical = 6.dp)
                            ) {
                                RadioButton(
                                    selected = state.playbackSpeed == spd,
                                    onClick = {
                                        engine.setPlaybackSpeed(spd)
                                        showSpeedDialog = false
                                    }
                                )
                                Text(if (spd == 1.0f) "1.0x (عادي)" else "${spd}x")
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSpeedDialog = false }) {
                        Text("إغلاق")
                    }
                }
            )
        }
    }
}

private fun formatPlayerClock(ms: Long): String {
    val safe = ms.coerceAtLeast(0L)
    val totalSec = safe / 1000L
    val hours = totalSec / 3600L
    val mins = (totalSec % 3600L) / 60L
    val secs = totalSec % 60L
    return if (hours > 0) {
        String.format(Locale.US, "%d:%02d:%02d", hours, mins, secs)
    } else {
        String.format(Locale.US, "%02d:%02d", mins, secs)
    }
}
