package com.floatsub.app.audio

import android.media.MediaCodec
import android.media.MediaFormat
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.random.Random

class OpusOggStreamEncoder(
    private val sampleRate: Int = 16000,
    private val channelCount: Int = 1,
    private val bitRate: Int = 24000
) {
    private var codec: MediaCodec? = null
    private val serialNumber: Int = Random.nextInt()
    private var pageSequenceNumber: Int = 0
    private var granulePosition48k: Long = 0L
    private var headersEmitted: Boolean = false
    private var isReleased: Boolean = false

    init {
        val format = MediaFormat.createAudioFormat(
            MediaFormat.MIMETYPE_AUDIO_OPUS,
            sampleRate,
            channelCount
        ).apply {
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_OPUS)
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()
        codec = encoder
    }

    fun encodePcmChunk(pcmBytes: ByteArray, length: Int): ByteArray {
        val activeCodec = codec ?: return ByteArray(0)
        if (isReleased || length <= 0) return ByteArray(0)

        val outputStream = ByteArrayOutputStream()

        if (!headersEmitted) {
            outputStream.write(buildOpusHeadPage())
            outputStream.write(buildOpusTagsPage())
            headersEmitted = true
        }

        var offset = 0
        while (offset < length) {
            val inputIndex = activeCodec.dequeueInputBuffer(5_000L)
            if (inputIndex < 0) break

            val inputBuffer = activeCodec.getInputBuffer(inputIndex) ?: break
            inputBuffer.clear()
            val toCopy = minOf(length - offset, inputBuffer.remaining())
            inputBuffer.put(pcmBytes, offset, toCopy)

            val ptsUs = (granulePosition48k * 1_000_000L) / 48_000L
            activeCodec.queueInputBuffer(inputIndex, 0, toCopy, ptsUs, 0)
            offset += toCopy

            drainEncoder(activeCodec, outputStream)
        }

        drainEncoder(activeCodec, outputStream)
        return outputStream.toByteArray()
    }

    private fun drainEncoder(activeCodec: MediaCodec, out: ByteArrayOutputStream) {
        val bufferInfo = MediaCodec.BufferInfo()
        while (true) {
            val outputIndex = activeCodec.dequeueOutputBuffer(bufferInfo, 0L)
            if (outputIndex < 0) break

            val isConfig = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
            val outputBuffer = activeCodec.getOutputBuffer(outputIndex)

            if (!isConfig && outputBuffer != null && bufferInfo.size > 0) {
                outputBuffer.position(bufferInfo.offset)
                outputBuffer.limit(bufferInfo.offset + bufferInfo.size)
                val packet = ByteArray(bufferInfo.size)
                outputBuffer.get(packet)

                val samples48k = parseOpusPacketSamples48k(packet)
                granulePosition48k += samples48k

                out.write(
                    createOggPage(
                        payload = packet,
                        headerType = 0x00,
                        granulePos = granulePosition48k
                    )
                )
            }
            activeCodec.releaseOutputBuffer(outputIndex, false)
        }
    }

    private fun buildOpusHeadPage(): ByteArray {
        val head = ByteBuffer.allocate(19).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("OpusHead".toByteArray(Charsets.US_ASCII))
            put(1.toByte())
            put(channelCount.toByte())
            putShort(312.toShort())
            putInt(sampleRate)
            putShort(0.toShort())
            put(0.toByte())
        }.array()

        return createOggPage(
            payload = head,
            headerType = 0x02,
            granulePos = 0L
        )
    }

    private fun buildOpusTagsPage(): ByteArray {
        val vendor = "FloatSub".toByteArray(Charsets.UTF_8)
        val tags = ByteBuffer.allocate(8 + 4 + vendor.size + 4)
            .order(ByteOrder.LITTLE_ENDIAN)
            .apply {
                put("OpusTags".toByteArray(Charsets.US_ASCII))
                putInt(vendor.size)
                put(vendor)
                putInt(0)
            }.array()

        return createOggPage(
            payload = tags,
            headerType = 0x00,
            granulePos = 0L
        )
    }

    private fun parseOpusPacketSamples48k(packet: ByteArray): Long {
        if (packet.isEmpty()) return 960L
        val toc = packet[0].toInt() and 0xFF
        val config = (toc shr 3) and 0x1F
        val frameDurationSamples48k = when {
            config < 12 -> when (config and 0x03) {
                0 -> 480
                1 -> 960
                2 -> 1920
                else -> 2880
            }
            config < 16 -> if ((config and 0x01) == 0) 480 else 960
            else -> when (config and 0x03) {
                0 -> 120
                1 -> 240
                2 -> 480
                else -> 960
            }
        }
        val frameCountCode = toc and 0x03
        val frameCount = when (frameCountCode) {
            0 -> 1
            1, 2 -> 2
            else -> if (packet.size > 1) (packet[1].toInt() and 0x3F).coerceAtLeast(1) else 1
        }
        return (frameDurationSamples48k * frameCount).toLong()
    }

    private fun createOggPage(
        payload: ByteArray,
        headerType: Int,
        granulePos: Long
    ): ByteArray {
        val laceValues = ArrayList<Byte>()
        var remaining = payload.size
        while (remaining >= 255) {
            laceValues.add(255.toByte())
            remaining -= 255
        }
        laceValues.add(remaining.toByte())

        val headerSize = 27 + laceValues.size
        val page = ByteArray(headerSize + payload.size)

        val buffer = ByteBuffer.wrap(page).order(ByteOrder.LITTLE_ENDIAN)
        buffer.put("OggS".toByteArray(Charsets.US_ASCII))
        buffer.put(0.toByte())
        buffer.put(headerType.toByte())
        buffer.putLong(granulePos)
        buffer.putInt(serialNumber)
        buffer.putInt(pageSequenceNumber++)
        buffer.putInt(0)
        buffer.put(laceValues.size.toByte())
        for (lace in laceValues) {
            buffer.put(lace)
        }
        buffer.put(payload)

        val crc = computeOggCrc32(page)
        buffer.putInt(22, crc)
        return page
    }

    fun release() {
        if (isReleased) return
        isReleased = true
        runCatching { codec?.stop() }
        runCatching { codec?.release() }
        codec = null
    }

    companion object {
        private val OGG_CRC_TABLE = IntArray(256).apply {
            for (i in 0 until 256) {
                var r = i shl 24
                repeat(8) {
                    r = if ((r and -0x80000000) != 0) {
                        (r shl 1) xor 0x04C11DB7
                    } else {
                        r shl 1
                    }
                }
                this[i] = r
            }
        }

        private fun computeOggCrc32(data: ByteArray): Int {
            var crc = 0
            for (b in data) {
                val index = ((crc ushr 24) xor (b.toInt() and 0xFF)) and 0xFF
                crc = (crc shl 8) xor OGG_CRC_TABLE[index]
            }
            return crc
        }
    }
}
