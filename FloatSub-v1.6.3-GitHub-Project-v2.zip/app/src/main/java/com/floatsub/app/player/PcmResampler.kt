package com.floatsub.app.player

import androidx.media3.common.C
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

object PcmResampler {

    const val TARGET_SAMPLE_RATE = 16000

    /**
     * يحول أي شريحة PCM خارجة من مفكك ExoPlayer (بأي تردد أو عدد قنوات)
     * إلى 16kHz Mono 16-bit Little-Endian جاهزة لمحركات التفريغ الصوتي.
     */
    fun to16kMono16Bit(
        rawBytes: ByteArray,
        sampleRateHz: Int,
        channelCount: Int,
        encoding: Int
    ): ByteArray {
        if (rawBytes.isEmpty() || sampleRateHz <= 0 || channelCount <= 0) {
            return ByteArray(0)
        }

        val monoSamples: ShortArray = when (encoding) {
            C.ENCODING_PCM_FLOAT -> decodeFloatToMonoShorts(rawBytes, channelCount)
            C.ENCODING_PCM_16BIT -> decode16BitToMonoShorts(rawBytes, channelCount)
            else -> return ByteArray(0)
        }

        if (monoSamples.isEmpty()) return ByteArray(0)

        val resampledShorts = if (sampleRateHz == TARGET_SAMPLE_RATE) {
            monoSamples
        } else {
            val outLength = ((monoSamples.size.toLong() * TARGET_SAMPLE_RATE) / sampleRateHz)
                .toInt()
                .coerceAtLeast(1)
            val out = ShortArray(outLength)
            val step = sampleRateHz.toDouble() / TARGET_SAMPLE_RATE.toDouble()
            val lastIndex = monoSamples.lastIndex

            for (i in 0 until outLength) {
                val srcPos = i * step
                val idx0 = srcPos.toInt().coerceIn(0, lastIndex)
                val idx1 = (idx0 + 1).coerceAtMost(lastIndex)
                val frac = srcPos - idx0
                val s0 = monoSamples[idx0].toDouble()
                val s1 = monoSamples[idx1].toDouble()
                val interpolated = (s0 + (s1 - s0) * frac)
                    .toInt()
                    .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                out[i] = interpolated.toShort()
            }
            out
        }

        val outBytes = ByteArray(resampledShorts.size * 2)
        ByteBuffer.wrap(outBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(resampledShorts)
        return outBytes
    }

    private fun decode16BitToMonoShorts(rawBytes: ByteArray, channelCount: Int): ShortArray {
        val bytesPerFrame = 2 * channelCount
        val frameCount = rawBytes.size / bytesPerFrame
        if (frameCount <= 0) return ShortArray(0)

        val buf = ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN)
        val mono = ShortArray(frameCount)
        val mixChannels = minOf(channelCount, 2)

        for (f in 0 until frameCount) {
            val baseOffset = f * bytesPerFrame
            var sum = 0
            for (ch in 0 until mixChannels) {
                sum += buf.getShort(baseOffset + ch * 2).toInt()
            }
            mono[f] = (sum / mixChannels).toShort()
        }
        return mono
    }

    private fun decodeFloatToMonoShorts(rawBytes: ByteArray, channelCount: Int): ShortArray {
        val bytesPerFrame = 4 * channelCount
        val frameCount = rawBytes.size / bytesPerFrame
        if (frameCount <= 0) return ShortArray(0)

        val buf = ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN)
        val mono = ShortArray(frameCount)
        val mixChannels = minOf(channelCount, 2)

        for (f in 0 until frameCount) {
            val baseOffset = f * bytesPerFrame
            var sum = 0f
            for (ch in 0 until mixChannels) {
                sum += buf.getFloat(baseOffset + ch * 4)
            }
            val avg = (sum / mixChannels).coerceIn(-1f, 1f)
            mono[f] = (avg * 32767f).toInt().toShort()
        }
        return mono
    }

    fun computeRms16Bit(pcmBytes: ByteArray, length: Int = pcmBytes.size): Double {
        val sampleCount = length / 2
        if (sampleCount <= 0) return 0.0
        var sumSquares = 0.0
        var i = 0
        while (i + 1 < length) {
            val low = pcmBytes[i].toInt() and 0xFF
            val high = pcmBytes[i + 1].toInt()
            val sample = ((high shl 8) or low).toShort().toDouble()
            sumSquares += sample * sample
            i += 2
        }
        return sqrt(sumSquares / sampleCount)
    }

    fun pcm16MonoToWav(pcmData: ByteArray, sampleRate: Int = TARGET_SAMPLE_RATE): ByteArray {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        val byteRate = sampleRate * 2
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(36 + pcmData.size)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16)
        header.putShort(1)
        header.putShort(1)
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort(2)
        header.putShort(16)
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(pcmData.size)

        val out = ByteArray(44 + pcmData.size)
        System.arraycopy(header.array(), 0, out, 0, 44)
        System.arraycopy(pcmData, 0, out, 44, pcmData.size)
        return out
    }
}
